package com.example

import com.example.util.BangladeshTelecomHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BangladeshTelecomHelperTest {

    @Test
    fun detectCarrier_recognizesBangladeshOperators() {
        assertEquals("GP", BangladeshTelecomHelper.detectCarrier("01711223344")?.shortCode)
        assertEquals("GP", BangladeshTelecomHelper.detectCarrier("+8801312345678")?.shortCode)
        assertEquals("Robi", BangladeshTelecomHelper.detectCarrier("01819000111")?.shortCode)
        assertEquals("Airtel", BangladeshTelecomHelper.detectCarrier("01678123456")?.shortCode)
        assertEquals("BL", BangladeshTelecomHelper.detectCarrier("01911223344")?.shortCode)
        assertEquals("BL", BangladeshTelecomHelper.detectCarrier("01401234567")?.shortCode)
        assertEquals("TT", BangladeshTelecomHelper.detectCarrier("01552123456")?.shortCode)
        assertNotNull(BangladeshTelecomHelper.detectCarrier("999"))
    }

    @Test
    fun formatPhoneNumber_formatsLocalAndCountryCodeNumbers() {
        assertEquals("01711-223344", BangladeshTelecomHelper.formatPhoneNumber("01711223344"))
        assertEquals("+880 1711-223344", BangladeshTelecomHelper.formatPhoneNumber("+8801711223344"))
        assertEquals("*121#", BangladeshTelecomHelper.formatPhoneNumber("*121#"))
    }

    @Test
    fun isUssdCode_detectsMmiAndUssdCodes() {
        assertTrue(BangladeshTelecomHelper.isUssdCode("*121#"))
        assertTrue(BangladeshTelecomHelper.isUssdCode("*121*1*2#"))
        assertFalse(BangladeshTelecomHelper.isUssdCode("01711223344"))
    }

    @Test
    fun toT9Digits_mapsNameLettersCorrectly() {
        assertEquals("72446", BangladeshTelecomHelper.toT9Digits("Rahim"))
        assertEquals("52746", BangladeshTelecomHelper.toT9Digits("Karim"))
    }
}
