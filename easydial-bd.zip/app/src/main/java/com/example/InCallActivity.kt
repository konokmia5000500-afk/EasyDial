package com.example

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.DevicePhoneRepository
import com.example.data.SettingsRepository
import com.example.model.AppLanguage
import com.example.model.AutoRecordMode
import com.example.model.CallerIdAnnouncementMode
import com.example.model.DialerSettings
import com.example.telecom.ActiveCallStatus
import com.example.telecom.CallManager
import com.example.telecom.CallRecordingManager
import com.example.telecom.RecordingPhase
import com.example.ui.screens.InCallScreen
import com.example.ui.theme.AlaapPhoneTheme
import com.example.util.BangladeshTelecomHelper
import com.example.util.LocalizedStrings
import kotlinx.coroutines.launch
import java.util.Locale

class InCallActivity : ComponentActivity() {

    private var proximityWakeLock: PowerManager.WakeLock? = null
    private var callerIdTts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        configureLockscreenFlags()
        acquireProximityLock()

        val settingsRepo = SettingsRepository(applicationContext)
        val phoneRepo = DevicePhoneRepository(applicationContext)

        setContent {
            val callState by CallManager.callState.collectAsStateWithLifecycle()
            val recordingState by CallRecordingManager.recordingState.collectAsStateWithLifecycle()
            val settings by settingsRepo.settingsFlow.collectAsStateWithLifecycle(initialValue = DialerSettings())
            val strings = LocalizedStrings.forLanguage(settings.language)
            val scope = rememberCoroutineScope()
            var autoTriggered by remember { mutableStateOf(false) }
            var callerPhotoUri by remember { mutableStateOf<String?>(null) }
            var announcedNumberKey by remember { mutableStateOf<String?>(null) }

            val micPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission(),
            ) { granted ->
                val active = callState
                if (granted && active != null && settings.callRecordingEnabled) {
                    CallRecordingManager.clearError()
                    CallRecordingManager.startRecording(
                        context = applicationContext,
                        phoneNumber = active.phoneNumber,
                        contactName = active.callerName,
                        announcementMode = settings.recordingAnnouncementMode,
                        language = settings.language,
                        micErrorMessage = strings.micPermissionRequired,
                    )
                }
            }

            LaunchedEffect(callState) {
                if (callState == null) {
                    CallRecordingManager.stopRecording(applicationContext)
                    finish()
                }
            }

            // Look up caller photo URI from Google Contacts
            LaunchedEffect(callState?.phoneNumber) {
                val number = callState?.phoneNumber.orEmpty()
                callerPhotoUri = phoneRepo.lookupCallerPhotoUri(number)
            }

            // Caller ID Voice Announcement when ringing
            LaunchedEffect(callState?.status, callState?.phoneNumber, settings.callerIdAnnouncement) {
                val active = callState ?: return@LaunchedEffect
                if (active.status == ActiveCallStatus.RINGING &&
                    settings.callerIdAnnouncement == CallerIdAnnouncementMode.ALWAYS &&
                    announcedNumberKey != active.phoneNumber
                ) {
                    announcedNumberKey = active.phoneNumber
                    val spokenTarget = active.callerName ?: active.formattedNumber.ifBlank { strings.unknownCaller }
                    val phrase = if (settings.language == AppLanguage.BANGLA) {
                        "ইনকামিং কল: $spokenTarget"
                    } else {
                        "Incoming call from $spokenTarget"
                    }
                    announceCallerViaTts(phrase, settings.language)
                } else if (active.status != ActiveCallStatus.RINGING) {
                    runCatching { callerIdTts?.stop() }
                }
            }

            // Flip To Silence sensor listener while ringing
            DisposableEffect(callState?.status, settings.flipToSilence) {
                val activeStatus = callState?.status
                val sensorManager = getSystemService(Context.SENSOR_SERVICE) as? SensorManager
                val accel = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
                if (activeStatus == ActiveCallStatus.RINGING && settings.flipToSilence && sensorManager != null && accel != null) {
                    var wasFaceUpOrTilted = false
                    var silenced = false
                    val listener = object : SensorEventListener {
                        override fun onSensorChanged(event: SensorEvent) {
                            val z = event.values.getOrNull(2) ?: return
                            if (z > 2.5f) {
                                wasFaceUpOrTilted = true
                            } else if (wasFaceUpOrTilted && z < -7.5f && !silenced) {
                                silenced = true
                                phoneRepo.silenceRinger()
                            }
                        }

                        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
                    }
                    sensorManager.registerListener(listener, accel, SensorManager.SENSOR_DELAY_UI)
                    onDispose {
                        sensorManager.unregisterListener(listener)
                    }
                } else {
                    onDispose { }
                }
            }

            // Auto-record trigger when call becomes ACTIVE (only if callRecordingEnabled is ON)
            LaunchedEffect(callState?.status, settings.callRecordingEnabled, settings.autoRecordMode) {
                val active = callState ?: return@LaunchedEffect
                if (!autoTriggered &&
                    active.status == ActiveCallStatus.ACTIVE &&
                    settings.callRecordingEnabled &&
                    recordingState.phase == RecordingPhase.IDLE
                ) {
                    val shouldAuto = when (settings.autoRecordMode) {
                        AutoRecordMode.MANUAL_ONLY -> false
                        AutoRecordMode.ALL_CALLS -> true
                        AutoRecordMode.UNKNOWN_NUMBERS -> active.callerName.isNullOrBlank()
                    }
                    if (shouldAuto && ContextCompat.checkSelfPermission(
                            applicationContext,
                            Manifest.permission.RECORD_AUDIO,
                        ) == PackageManager.PERMISSION_GRANTED
                    ) {
                        autoTriggered = true
                        CallRecordingManager.startRecording(
                            context = applicationContext,
                            phoneNumber = active.phoneNumber,
                            contactName = active.callerName,
                            announcementMode = settings.recordingAnnouncementMode,
                            language = settings.language,
                            micErrorMessage = strings.micPermissionRequired,
                        )
                    }
                }
            }

            callState?.let { activeCall ->
                val normalized = BangladeshTelecomHelper.normalizeDigits(activeCall.phoneNumber)
                val resolvedCardPath = settings.contactCallingCards[normalized] ?: settings.defaultCallingCardPath

                AlaapPhoneTheme(themeMode = settings.themeMode) {
                    InCallScreen(
                        callState = activeCall,
                        recordingState = recordingState,
                        callRecordingEnabled = settings.callRecordingEnabled,
                        announcementMode = settings.recordingAnnouncementMode,
                        incomingCallGesture = settings.incomingCallGesture,
                        photoUri = callerPhotoUri,
                        callingCardPath = resolvedCardPath,
                        callingCardStyle = settings.defaultCallingCardStyle,
                        strings = strings,
                        language = settings.language,
                        quickResponses = settings.quickResponses,
                        onAnswer = {
                            runCatching { callerIdTts?.stop() }
                            CallManager.answerCall()
                        },
                        onDecline = { msg ->
                            runCatching { callerIdTts?.stop() }
                            CallManager.rejectCall(msg)
                        },
                        onEndCall = {
                            CallRecordingManager.stopRecording(applicationContext)
                            CallManager.endCall()
                        },
                        onToggleMute = { CallManager.toggleMute() },
                        onToggleSpeaker = { CallManager.toggleSpeaker() },
                        onToggleBluetooth = { CallManager.toggleBluetooth() },
                        onToggleHold = { CallManager.toggleHold() },
                        onPlayDtmf = { ch -> CallManager.playDtmf(ch) },
                        onToggleRecording = {
                            if (!settings.callRecordingEnabled) return@InCallScreen
                            val hasMic = ContextCompat.checkSelfPermission(
                                applicationContext,
                                Manifest.permission.RECORD_AUDIO,
                            ) == PackageManager.PERMISSION_GRANTED
                            if (!hasMic) {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            } else {
                                CallRecordingManager.startOrStopRecording(
                                    context = applicationContext,
                                    phoneNumber = activeCall.phoneNumber,
                                    contactName = activeCall.callerName,
                                    announcementMode = settings.recordingAnnouncementMode,
                                    language = settings.language,
                                    micErrorMessage = strings.micPermissionRequired,
                                )
                            }
                        },
                        onToggleAnnouncementMode = { newMode ->
                            scope.launch {
                                settingsRepo.setRecordingAnnouncementMode(newMode)
                            }
                        },
                    )
                }
            }
        }
    }

    private fun announceCallerViaTts(phrase: String, language: AppLanguage) {
        callerIdTts?.shutdown()
        callerIdTts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val locale = if (language == AppLanguage.BANGLA) {
                    Locale.forLanguageTag("bn-BD")
                } else {
                    Locale.US
                }
                val support = callerIdTts?.setLanguage(locale)
                if (support == TextToSpeech.LANG_MISSING_DATA || support == TextToSpeech.LANG_NOT_SUPPORTED) {
                    callerIdTts?.language = Locale.US
                }
                callerIdTts?.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "alaap_caller_id")
            }
        }
    }

    private fun configureLockscreenFlags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }
    }

    private fun acquireProximityLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return
        if (pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) {
            proximityWakeLock = pm.newWakeLock(
                PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK,
                "AlaapPhone::ProximityWakeLock",
            ).apply {
                if (!isHeld) acquire(60 * 60 * 1000L)
            }
        }
    }

    override fun onDestroy() {
        runCatching { callerIdTts?.shutdown() }
        callerIdTts = null
        proximityWakeLock?.let {
            if (it.isHeld) it.release()
        }
        proximityWakeLock = null
        super.onDestroy()
    }
}
