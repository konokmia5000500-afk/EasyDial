package com.example.model

enum class AppLanguage(val code: String, val displayName: String) {
    ENGLISH("en", "English"),
    BANGLA("bn", "বাংলা"),
}

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK,
}

enum class SimPreference {
    ASK_EVERY_TIME,
    SIM_1,
    SIM_2,
}

enum class RecordingAnnouncementMode {
    ANNOUNCE_BOTH_SIDES,
    SILENT_NO_ANNOUNCEMENT,
}

enum class AutoRecordMode {
    MANUAL_ONLY,
    ALL_CALLS,
    UNKNOWN_NUMBERS,
}

enum class IncomingCallGesture {
    SWIPE,
    SINGLE_TAP,
}

enum class CallerIdAnnouncementMode {
    NEVER,
    ALWAYS,
}

enum class CallDirectionType {
    INCOMING,
    OUTGOING,
    MISSED,
    REJECTED,
    BLOCKED,
    VOICEMAIL,
}

enum class RecentsFilter {
    ALL,
    MISSED,
    CONTACTS,
    OUTGOING,
    INCOMING,
}

enum class DialerTab {
    HOME,
    KEYPAD,
}

data class BangladeshCarrier(
    val nameEn: String,
    val nameBn: String,
    val shortCode: String,
    val colorHex: Long,
    val isEmergency: Boolean = false,
)

data class PhoneNumberEntry(
    val number: String,
    val normalized: String,
    val typeLabel: String,
)

data class ContactEntry(
    val id: Long,
    val lookupKey: String,
    val name: String,
    val numbers: List<PhoneNumberEntry>,
    val photoUri: String?,
    val isStarred: Boolean,
    val t9NameDigits: String,
    val primaryCarrier: BangladeshCarrier?,
)

data class CallLogEntry(
    val id: Long,
    val number: String,
    val formattedNumber: String,
    val cachedName: String?,
    val type: CallDirectionType,
    val dateMillis: Long,
    val durationSeconds: Long,
    val phoneAccountId: String?,
    val simSlotLabel: String?,
    val photoUri: String?,
    val carrier: BangladeshCarrier?,
)

data class GroupedCallLogItem(
    val primary: CallLogEntry,
    val count: Int,
    val entries: List<CallLogEntry>,
)

data class SimAccountInfo(
    val id: String,
    val slotIndex: Int,
    val displayName: String,
    val carrierName: String,
    val phoneNumber: String?,
)

data class UssdShortcut(
    val code: String,
    val titleEn: String,
    val titleBn: String,
    val operatorEn: String,
    val operatorBn: String,
    val badgeColorHex: Long,
)

data class CallRecordingItem(
    val filePath: String,
    val fileName: String,
    val phoneNumber: String,
    val contactName: String?,
    val timestampMillis: Long,
    val durationMillis: Long,
    val sizeBytes: Long,
    val announced: Boolean,
)

data class DialerSettings(
    val language: AppLanguage = AppLanguage.ENGLISH,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dialpadTones: Boolean = true,
    val dialpadVibrate: Boolean = true,
    val vibrateOnConnect: Boolean = true,
    val simPreference: SimPreference = SimPreference.ASK_EVERY_TIME,
    val sortByLastName: Boolean = false,
    val callRecordingEnabled: Boolean = false,
    val recordingAnnouncementMode: RecordingAnnouncementMode = RecordingAnnouncementMode.ANNOUNCE_BOTH_SIDES,
    val autoRecordMode: AutoRecordMode = AutoRecordMode.MANUAL_ONLY,
    val incomingCallGesture: IncomingCallGesture = IncomingCallGesture.SWIPE,
    val callerIdAndSpamEnabled: Boolean = true,
    val callerIdAnnouncement: CallerIdAnnouncementMode = CallerIdAnnouncementMode.NEVER,
    val flipToSilence: Boolean = false,
    val defaultCallingCardPath: String? = null,
    val defaultCallingCardStyle: Int = 0,
    val contactCallingCards: Map<String, String> = emptyMap(),
    val blockedNumbers: Set<String> = emptySet(),
    val quickResponses: List<String> = listOf(
        "I'll call you right back.",
        "Can't talk now. What's up?",
        "I'm in a meeting, will call later.",
        "এখন ব্যস্ত আছি, একটু পর কল করছি।",
    ),
)

data class PermissionStatus(
    val hasPhoneAndCallLog: Boolean = false,
    val hasContacts: Boolean = false,
    val hasPhoneState: Boolean = false,
    val hasRecordAudio: Boolean = false,
    val isDefaultDialer: Boolean = false,
) {
    val allCoreGranted: Boolean
        get() = hasPhoneAndCallLog && hasContacts
}
