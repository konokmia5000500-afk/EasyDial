package com.example.telecom

import android.net.Uri
import android.os.Build
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import com.example.model.BangladeshCarrier
import com.example.util.BangladeshTelecomHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ActiveCallStatus {
    DIALING,
    RINGING,
    ACTIVE,
    HOLDING,
    DISCONNECTING,
    DISCONNECTED,
}

data class ActiveCallUiState(
    val phoneNumber: String,
    val formattedNumber: String,
    val callerName: String?,
    val carrier: BangladeshCarrier?,
    val status: ActiveCallStatus,
    val connectedAtMillis: Long?,
    val isMuted: Boolean,
    val isSpeakerOn: Boolean,
    val isBluetoothAvailable: Boolean,
    val isBluetoothActive: Boolean,
)

object CallManager {

    private var inCallService: InCallService? = null
    private var currentCall: Call? = null

    private val _callState = MutableStateFlow<ActiveCallUiState?>(null)
    val callState: StateFlow<ActiveCallUiState?> = _callState.asStateFlow()

    private val callCallback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            updateFromCall(call, state)
        }

        override fun onDetailsChanged(call: Call, details: Call.Details) {
            updateFromCall(call, call.currentStateCompat())
        }
    }

    fun attachService(service: InCallService) {
        inCallService = service
    }

    fun detachService() {
        inCallService = null
    }

    fun onCallAdded(call: Call) {
        currentCall?.unregisterCallback(callCallback)
        currentCall = call
        call.registerCallback(callCallback)
        updateFromCall(call, call.currentStateCompat())
    }

    fun onCallRemoved(call: Call) {
        call.unregisterCallback(callCallback)
        if (currentCall == call) {
            CallRecordingManager.stopRecording()
            currentCall = null
            _callState.value = null
        }
    }

    fun onAudioStateChanged(audioState: CallAudioState?) {
        val existing = _callState.value ?: return
        if (audioState == null) return
        _callState.value = existing.copy(
            isMuted = audioState.isMuted,
            isSpeakerOn = audioState.route == CallAudioState.ROUTE_SPEAKER,
            isBluetoothAvailable = (audioState.supportedRouteMask and CallAudioState.ROUTE_BLUETOOTH) != 0,
            isBluetoothActive = audioState.route == CallAudioState.ROUTE_BLUETOOTH,
        )
    }

    fun answerCall() {
        currentCall?.answer(VideoProfile.STATE_AUDIO_ONLY)
    }

    fun rejectCall(message: String? = null) {
        val call = currentCall ?: return
        if (call.currentStateCompat() == Call.STATE_RINGING) {
            if (!message.isNullOrBlank()) {
                call.reject(true, message)
            } else {
                call.reject(false, null)
            }
        } else {
            call.disconnect()
        }
    }

    fun endCall() {
        currentCall?.disconnect()
    }

    fun toggleMute() {
        val service = inCallService ?: return
        val currentlyMuted = _callState.value?.isMuted ?: false
        @Suppress("DEPRECATION")
        service.setMuted(!currentlyMuted)
    }

    fun toggleSpeaker() {
        val service = inCallService ?: return
        val currentlySpeaker = _callState.value?.isSpeakerOn ?: false
        val targetRoute = if (currentlySpeaker) {
            CallAudioState.ROUTE_WIRED_OR_EARPIECE
        } else {
            CallAudioState.ROUTE_SPEAKER
        }
        @Suppress("DEPRECATION")
        service.setAudioRoute(targetRoute)
    }

    fun toggleBluetooth() {
        val service = inCallService ?: return
        val currentlyBt = _callState.value?.isBluetoothActive ?: false
        val targetRoute = if (currentlyBt) {
            CallAudioState.ROUTE_WIRED_OR_EARPIECE
        } else {
            CallAudioState.ROUTE_BLUETOOTH
        }
        @Suppress("DEPRECATION")
        service.setAudioRoute(targetRoute)
    }

    fun toggleHold() {
        val call = currentCall ?: return
        if (call.currentStateCompat() == Call.STATE_HOLDING) {
            call.unhold()
        } else {
            call.hold()
        }
    }

    fun playDtmf(digit: Char) {
        val call = currentCall ?: return
        call.playDtmfTone(digit)
        call.stopDtmfTone()
    }

    private fun updateFromCall(call: Call, state: Int) {
        val handleUri: Uri? = call.details?.handle
        val rawNumber = handleUri?.schemeSpecificPart?.trim().orEmpty()
        val displayName = call.details?.contactDisplayName?.takeIf { it.isNotBlank() }
            ?: call.details?.callerDisplayName?.takeIf { it.isNotBlank() }

        val mappedStatus = when (state) {
            Call.STATE_RINGING -> ActiveCallStatus.RINGING
            Call.STATE_DIALING, Call.STATE_CONNECTING, Call.STATE_NEW, Call.STATE_SELECT_PHONE_ACCOUNT ->
                ActiveCallStatus.DIALING
            Call.STATE_ACTIVE -> ActiveCallStatus.ACTIVE
            Call.STATE_HOLDING -> ActiveCallStatus.HOLDING
            Call.STATE_DISCONNECTING -> ActiveCallStatus.DISCONNECTING
            Call.STATE_DISCONNECTED -> ActiveCallStatus.DISCONNECTED
            else -> ActiveCallStatus.DIALING
        }

        val previous = _callState.value
        val connectedAt = when {
            mappedStatus == ActiveCallStatus.ACTIVE && previous?.connectedAtMillis != null ->
                previous.connectedAtMillis
            mappedStatus == ActiveCallStatus.ACTIVE -> System.currentTimeMillis()
            else -> previous?.connectedAtMillis
        }

        @Suppress("DEPRECATION")
        val audioState = inCallService?.callAudioState
        _callState.value = ActiveCallUiState(
            phoneNumber = rawNumber,
            formattedNumber = BangladeshTelecomHelper.formatPhoneNumber(rawNumber),
            callerName = displayName,
            carrier = BangladeshTelecomHelper.detectCarrier(rawNumber),
            status = mappedStatus,
            connectedAtMillis = connectedAt,
            isMuted = audioState?.isMuted ?: false,
            isSpeakerOn = audioState?.route == CallAudioState.ROUTE_SPEAKER,
            isBluetoothAvailable = audioState?.let {
                (it.supportedRouteMask and CallAudioState.ROUTE_BLUETOOTH) != 0
            } ?: false,
            isBluetoothActive = audioState?.route == CallAudioState.ROUTE_BLUETOOTH,
        )
    }

    private fun Call.currentStateCompat(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            details.state
        } else {
            @Suppress("DEPRECATION")
            state
        }
    }
}
