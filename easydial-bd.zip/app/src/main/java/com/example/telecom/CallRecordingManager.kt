package com.example.telecom

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.content.ContextCompat
import com.example.model.AppLanguage
import com.example.model.CallRecordingItem
import com.example.model.RecordingAnnouncementMode
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.File
import java.util.Locale

enum class RecordingPhase {
    IDLE,
    ANNOUNCING,
    RECORDING,
}

data class RecordingUiState(
    val phase: RecordingPhase = RecordingPhase.IDLE,
    val announcementMode: RecordingAnnouncementMode = RecordingAnnouncementMode.ANNOUNCE_BOTH_SIDES,
    val startedAtMillis: Long? = null,
    val activeFilePath: String? = null,
    val errorMessage: String? = null,
    val lastCompletedAtMillis: Long = 0L,
)

object CallRecordingManager {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var mediaRecorder: MediaRecorder? = null
    private var tts: TextToSpeech? = null
    private var startJob: Job? = null

    private var activeNumber: String = ""
    private var activeName: String? = null
    private var activeTimestamp: Long = 0L
    private var activeAnnounced: Boolean = true
    private var activeFile: File? = null

    private val _recordingState = MutableStateFlow(RecordingUiState())
    val recordingState: StateFlow<RecordingUiState> = _recordingState.asStateFlow()

    fun getRecordingsDir(context: Context): File {
        val dir = File(context.filesDir, "call_recordings")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun startOrStopRecording(
        context: Context,
        phoneNumber: String,
        contactName: String?,
        announcementMode: RecordingAnnouncementMode,
        language: AppLanguage,
        micErrorMessage: String,
    ) {
        val currentPhase = _recordingState.value.phase
        if (currentPhase == RecordingPhase.RECORDING || currentPhase == RecordingPhase.ANNOUNCING) {
            stopRecording(context)
            return
        }
        startRecording(
            context = context,
            phoneNumber = phoneNumber,
            contactName = contactName,
            announcementMode = announcementMode,
            language = language,
            micErrorMessage = micErrorMessage,
        )
    }

    fun startRecording(
        context: Context,
        phoneNumber: String,
        contactName: String?,
        announcementMode: RecordingAnnouncementMode,
        language: AppLanguage,
        micErrorMessage: String,
    ) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            _recordingState.value = _recordingState.value.copy(errorMessage = micErrorMessage)
            return
        }

        if (_recordingState.value.phase != RecordingPhase.IDLE) return

        startJob?.cancel()
        startJob = scope.launch {
            val announce = announcementMode == RecordingAnnouncementMode.ANNOUNCE_BOTH_SIDES
            _recordingState.value = RecordingUiState(
                phase = if (announce) RecordingPhase.ANNOUNCING else RecordingPhase.RECORDING,
                announcementMode = announcementMode,
                errorMessage = null,
            )

            if (announce) {
                playAnnouncementAndWait(context.applicationContext, language)
                if (_recordingState.value.phase != RecordingPhase.ANNOUNCING) {
                    return@launch
                }
            }

            val began = withContext(Dispatchers.IO) {
                beginMediaRecorder(
                    context = context.applicationContext,
                    phoneNumber = phoneNumber,
                    contactName = contactName,
                    announced = announce,
                )
            }

            if (began) {
                _recordingState.value = RecordingUiState(
                    phase = RecordingPhase.RECORDING,
                    announcementMode = announcementMode,
                    startedAtMillis = System.currentTimeMillis(),
                    activeFilePath = activeFile?.absolutePath,
                )
            } else {
                _recordingState.value = RecordingUiState(
                    phase = RecordingPhase.IDLE,
                    announcementMode = announcementMode,
                    errorMessage = "Audio recorder unavailable on this device.",
                )
            }
        }
    }

    fun stopRecording(context: Context? = null) {
        startJob?.cancel()
        startJob = null

        val recorder = mediaRecorder
        mediaRecorder = null
        val startedAt = _recordingState.value.startedAtMillis
        val savedFile = activeFile
        val num = activeNumber
        val name = activeName
        val ts = activeTimestamp
        val announced = activeAnnounced

        if (recorder != null) {
            runCatching { recorder.stop() }
            runCatching { recorder.reset() }
            runCatching { recorder.release() }
        }

        var completedAt = _recordingState.value.lastCompletedAtMillis
        if (savedFile != null && savedFile.exists() && startedAt != null) {
            val durationMs = (System.currentTimeMillis() - startedAt).coerceAtLeast(0L)
            if (durationMs < 350L || savedFile.length() == 0L) {
                savedFile.delete()
            } else {
                writeMetadataSidecar(
                    audioFile = savedFile,
                    phoneNumber = num,
                    contactName = name,
                    timestampMillis = ts,
                    durationMillis = durationMs,
                    announced = announced,
                )
                completedAt = System.currentTimeMillis()
            }
        }

        activeFile = null
        _recordingState.value = RecordingUiState(
            phase = RecordingPhase.IDLE,
            lastCompletedAtMillis = completedAt,
        )
        if (context != null) {
            runCatching { tts?.stop() }
        }
    }

    fun clearError() {
        _recordingState.value = _recordingState.value.copy(errorMessage = null)
    }

    private suspend fun playAnnouncementAndWait(context: Context, language: AppLanguage) {
        val phrase = if (language == AppLanguage.BANGLA) {
            "এই কলটি এখন রেকর্ড করা হচ্ছে।"
        } else {
            "This call is now being recorded."
        }
        val targetLocale = if (language == AppLanguage.BANGLA) {
            Locale.forLanguageTag("bn-BD")
        } else {
            Locale.US
        }

        val tonePlayed = runCatching {
            val tg = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 75)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 200)
            delay(230L)
            tg.release()
            true
        }.getOrDefault(false)

        val ttsReady = CompletableDeferred<Boolean>()
        val utteranceDone = CompletableDeferred<Unit>()

        withContext(Dispatchers.Main) {
            tts?.shutdown()
            tts = TextToSpeech(context) { status ->
                ttsReady.complete(status == TextToSpeech.SUCCESS)
            }
        }

        val ready = withTimeoutOrNull(1200L) { ttsReady.await() } ?: false
        if (ready) {
            withContext(Dispatchers.Main) {
                val engine = tts ?: return@withContext
                val langSupport = engine.setLanguage(targetLocale)
                if (langSupport == TextToSpeech.LANG_MISSING_DATA || langSupport == TextToSpeech.LANG_NOT_SUPPORTED) {
                    engine.language = Locale.US
                }
                engine.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                val utteranceId = "alaap_rec_announce_${System.currentTimeMillis()}"
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) {
                        utteranceDone.complete(Unit)
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) {
                        utteranceDone.complete(Unit)
                    }
                })
                val params = Bundle().apply {
                    putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_VOICE_CALL)
                }
                val speakText = if (langSupport == TextToSpeech.LANG_MISSING_DATA || langSupport == TextToSpeech.LANG_NOT_SUPPORTED) {
                    "This call is now being recorded."
                } else {
                    phrase
                }
                val result = engine.speak(speakText, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
                if (result != TextToSpeech.SUCCESS) {
                    utteranceDone.complete(Unit)
                }
            }
            withTimeoutOrNull(2500L) { utteranceDone.await() }
        } else if (!tonePlayed) {
            delay(900L)
        }
    }

    private fun beginMediaRecorder(
        context: Context,
        phoneNumber: String,
        contactName: String?,
        announced: Boolean,
    ): Boolean {
        val dir = getRecordingsDir(context)
        val ts = System.currentTimeMillis()
        val safeDigits = phoneNumber.filter { it.isDigit() || it == '+' }.ifBlank { "unknown" }
        val file = File(dir, "rec_${ts}_$safeDigits.m4a")

        activeNumber = phoneNumber
        activeName = contactName
        activeTimestamp = ts
        activeAnnounced = announced
        activeFile = file

        val candidateSources = listOf(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.MIC,
        )

        for (source in candidateSources) {
            val recorder = createMediaRecorder(context)
            val ok = runCatching {
                recorder.setAudioSource(source)
                recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                recorder.setAudioChannels(1)
                recorder.setAudioSamplingRate(44100)
                recorder.setAudioEncodingBitRate(96000)
                recorder.setOutputFile(file.absolutePath)
                recorder.setOnErrorListener { _, _, _ ->
                    stopRecording(context)
                }
                recorder.prepare()
                recorder.start()
                true
            }.getOrDefault(false)

            if (ok) {
                mediaRecorder = recorder
                return true
            } else {
                runCatching { recorder.reset() }
                runCatching { recorder.release() }
                if (file.exists()) file.delete()
            }
        }
        activeFile = null
        return false
    }

    private fun createMediaRecorder(context: Context): MediaRecorder {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }
    }

    private fun writeMetadataSidecar(
        audioFile: File,
        phoneNumber: String,
        contactName: String?,
        timestampMillis: Long,
        durationMillis: Long,
        announced: Boolean,
    ) {
        val metaFile = File(audioFile.parentFile, "${audioFile.nameWithoutExtension}.json")
        val json = JSONObject().apply {
            put("phoneNumber", phoneNumber)
            put("contactName", contactName ?: "")
            put("timestampMillis", timestampMillis)
            put("durationMillis", durationMillis)
            put("announced", announced)
        }
        runCatching { metaFile.writeText(json.toString()) }
    }

    suspend fun loadRecordings(context: Context): List<CallRecordingItem> = withContext(Dispatchers.IO) {
        val dir = getRecordingsDir(context)
        val audioFiles = dir.listFiles { f -> f.isFile && f.extension.equals("m4a", ignoreCase = true) }
            ?: return@withContext emptyList()

        audioFiles.mapNotNull { file ->
            if (file.length() == 0L) return@mapNotNull null
            val metaFile = File(dir, "${file.nameWithoutExtension}.json")
            val json = runCatching {
                if (metaFile.exists()) JSONObject(metaFile.readText()) else null
            }.getOrNull()

            val number = json?.optString("phoneNumber").orEmpty().ifBlank {
                file.nameWithoutExtension.substringAfterLast('_', "Unknown")
            }
            val contactName = json?.optString("contactName")?.takeIf { it.isNotBlank() }
            val ts = json?.optLong("timestampMillis")?.takeIf { it > 0L } ?: file.lastModified()
            val announced = json?.optBoolean("announced", true) ?: true
            var durationMs = json?.optLong("durationMillis") ?: 0L
            if (durationMs <= 0L) {
                durationMs = readAudioDurationMs(file)
            }

            CallRecordingItem(
                filePath = file.absolutePath,
                fileName = file.name,
                phoneNumber = number,
                contactName = contactName,
                timestampMillis = ts,
                durationMillis = durationMs,
                sizeBytes = file.length(),
                announced = announced,
            )
        }.sortedByDescending { it.timestampMillis }
    }

    suspend fun deleteRecording(filePath: String): Boolean = withContext(Dispatchers.IO) {
        val audioFile = File(filePath)
        val metaFile = File(audioFile.parentFile, "${audioFile.nameWithoutExtension}.json")
        if (metaFile.exists()) metaFile.delete()
        if (audioFile.exists()) audioFile.delete() else false
    }

    private fun readAudioDurationMs(file: File): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        } finally {
            runCatching { retriever.release() }
        }
    }
}
