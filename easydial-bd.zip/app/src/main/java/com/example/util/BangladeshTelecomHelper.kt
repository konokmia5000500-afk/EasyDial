package com.example.util

import com.example.model.BangladeshCarrier
import com.example.model.UssdShortcut

object BangladeshTelecomHelper {

    private val gp = BangladeshCarrier("Grameenphone", "গ্রামীণফোন", "GP", 0xFF0099DF)
    private val robi = BangladeshCarrier("Robi", "রবি", "Robi", 0xFFE31837)
    private val airtel = BangladeshCarrier("Airtel", "এয়ারটেল", "Airtel", 0xFFED1C24)
    private val banglalink = BangladeshCarrier("Banglalink", "বাংলালিংক", "BL", 0xFFF36F21)
    private val teletalk = BangladeshCarrier("Teletalk", "টেলিটক", "TT", 0xFF008749)
    private val emergency = BangladeshCarrier("Emergency BD", "জরুরি সেবা", "SOS", 0xFFD93025, isEmergency = true)

    private val emergencyNumbers = setOf("999", "333", "109", "16263", "106", "102", "1090", "100", "101")

    fun normalizeDigits(raw: String): String {
        val cleaned = raw.filter { it.isDigit() || it == '+' }
        return when {
            cleaned.startsWith("+880") -> "0" + cleaned.removePrefix("+880")
            cleaned.startsWith("880") && cleaned.length >= 13 -> "0" + cleaned.removePrefix("880")
            else -> cleaned
        }
    }

    fun isUssdCode(input: String): Boolean {
        val trimmed = input.trim()
        return (trimmed.startsWith("*") || trimmed.startsWith("#")) && trimmed.endsWith("#") && trimmed.length >= 3
    }

    fun detectCarrier(rawNumber: String): BangladeshCarrier? {
        val trimmed = rawNumber.trim()
        if (trimmed in emergencyNumbers) return emergency
        val normalized = normalizeDigits(trimmed)
        if (!normalized.startsWith("01") || normalized.length < 3) return null
        return when (normalized.substring(0, 3)) {
            "017", "013" -> gp
            "018" -> robi
            "016" -> airtel
            "019", "014" -> banglalink
            "015" -> teletalk
            else -> null
        }
    }

    fun formatPhoneNumber(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isEmpty() || isUssdCode(trimmed)) return trimmed
        val digitsOnly = trimmed.filter { it.isDigit() || it == '+' }
        return when {
            digitsOnly.startsWith("+8801") && digitsOnly.length == 14 -> {
                "+880 ${digitsOnly.substring(4, 8)}-${digitsOnly.substring(8)}"
            }
            digitsOnly.startsWith("01") && digitsOnly.length == 11 -> {
                "${digitsOnly.substring(0, 5)}-${digitsOnly.substring(5)}"
            }
            else -> trimmed
        }
    }

    fun toT9Digits(text: String): String {
        val sb = StringBuilder(text.length)
        for (ch in text.lowercase()) {
            when (ch) {
                in 'a'..'c' -> sb.append('2')
                in 'd'..'f' -> sb.append('3')
                in 'g'..'i' -> sb.append('4')
                in 'j'..'l' -> sb.append('5')
                in 'm'..'o' -> sb.append('6')
                in 'p'..'s' -> sb.append('7')
                in 't'..'v' -> sb.append('8')
                in 'w'..'z' -> sb.append('9')
                in '0'..'9' -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    val bangladeshUssdShortcuts: List<UssdShortcut> = listOf(
        UssdShortcut("*121#", "GP Main Menu", "জিপি মেইন মেনু", "Grameenphone", "গ্রামীণফোন", 0xFF0099DF),
        UssdShortcut("*566#", "GP Balance Check", "জিপি ব্যালেন্স চেক", "Grameenphone", "গ্রামীণফোন", 0xFF0099DF),
        UssdShortcut("*121*1*2#", "GP Internet Balance", "জিপি এমবি চেক", "Grameenphone", "গ্রামীণফোন", 0xFF0099DF),
        UssdShortcut("*2#", "GP Own Number", "জিপি নিজের নম্বর", "Grameenphone", "গ্রামীণফোন", 0xFF0099DF),
        UssdShortcut("*222#", "Robi Balance Check", "রবি ব্যালেন্স চেক", "Robi", "রবি", 0xFFE31837),
        UssdShortcut("*8444*88#", "Robi Internet Balance", "রবি এমবি চেক", "Robi", "রবি", 0xFFE31837),
        UssdShortcut("*2#", "Robi Own Number", "রবি নিজের নম্বর", "Robi", "রবি", 0xFFE31837),
        UssdShortcut("*778#", "Airtel Balance Check", "এয়ারটেল ব্যালেন্স চেক", "Airtel", "এয়ারটেল", 0xFFED1C24),
        UssdShortcut("*3#", "Airtel Internet Balance", "এয়ারটেল এমবি চেক", "Airtel", "এয়ারটেল", 0xFFED1C24),
        UssdShortcut("*124#", "Banglalink Balance", "বাংলালিংক ব্যালেন্স", "Banglalink", "বাংলালিংক", 0xFFF36F21),
        UssdShortcut("*5000*500#", "Banglalink Internet", "বাংলালিংক এমবি চেক", "Banglalink", "বাংলালিংক", 0xFFF36F21),
        UssdShortcut("*511#", "Banglalink Own Number", "বাংলালিংক নিজের নম্বর", "Banglalink", "বাংলালিংক", 0xFFF36F21),
        UssdShortcut("*152#", "Teletalk Balance", "টেলিটক ব্যালেন্স", "Teletalk", "টেলিটক", 0xFF008749),
        UssdShortcut("*551#", "Teletalk Own Number", "টেলিটক নিজের নম্বর", "Teletalk", "টেলিটক", 0xFF008749),
        UssdShortcut("999", "National Emergency", "জাতীয় জরুরি সেবা", "Emergency", "জরুরি", 0xFFD93025),
        UssdShortcut("333", "Govt Info & Services", "সরকারি তথ্য সেবা", "Emergency", "জরুরি", 0xFFD93025),
        UssdShortcut("16263", "Health Helpline", "স্বাস্থ্য বাতায়ন", "Emergency", "জরুরি", 0xFFD93025),
    )
}
