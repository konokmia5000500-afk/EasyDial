package com.example.data

import android.content.Context
import android.net.Uri
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppLanguage
import com.example.model.AutoRecordMode
import com.example.model.CallerIdAnnouncementMode
import com.example.model.DialerSettings
import com.example.model.IncomingCallGesture
import com.example.model.RecordingAnnouncementMode
import com.example.model.SimPreference
import com.example.model.ThemeMode
import com.example.util.BangladeshTelecomHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

private val Context.dialerDataStore by preferencesDataStore(name = "alaap_dialer_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("language")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DIALPAD_TONES = booleanPreferencesKey("dialpad_tones")
        val DIALPAD_VIBRATE = booleanPreferencesKey("dialpad_vibrate")
        val VIBRATE_ON_CONNECT = booleanPreferencesKey("vibrate_on_connect")
        val SIM_PREFERENCE = stringPreferencesKey("sim_preference")
        val SORT_BY_LAST_NAME = booleanPreferencesKey("sort_by_last_name")
        val CALL_RECORDING_ENABLED = booleanPreferencesKey("call_recording_enabled")
        val RECORDING_ANNOUNCEMENT_MODE = stringPreferencesKey("recording_announcement_mode")
        val AUTO_RECORD_MODE = stringPreferencesKey("auto_record_mode")
        val INCOMING_CALL_GESTURE = stringPreferencesKey("incoming_call_gesture")
        val CALLER_ID_AND_SPAM = booleanPreferencesKey("caller_id_and_spam")
        val CALLER_ID_ANNOUNCEMENT = stringPreferencesKey("caller_id_announcement")
        val FLIP_TO_SILENCE = booleanPreferencesKey("flip_to_silence")
        val DEFAULT_CALLING_CARD_PATH = stringPreferencesKey("default_calling_card_path")
        val DEFAULT_CALLING_CARD_STYLE = intPreferencesKey("default_calling_card_style")
        val CONTACT_CALLING_CARDS_JSON = stringPreferencesKey("contact_calling_cards_json")
        val BLOCKED_NUMBERS = stringSetPreferencesKey("blocked_numbers")
        val QUICK_RESPONSES = stringPreferencesKey("quick_responses_serialized")
    }

    private val defaultQuickResponses = listOf(
        "I'll call you right back.",
        "Can't talk now. What's up?",
        "I'm in a meeting, will call later.",
        "এখন ব্যস্ত আছি, একটু পর কল করছি।",
    )

    val settingsFlow: Flow<DialerSettings> = context.dialerDataStore.data.map { prefs ->
        val serializedQuick = prefs[Keys.QUICK_RESPONSES]
        val quickList = if (serializedQuick.isNullOrBlank()) {
            defaultQuickResponses
        } else {
            serializedQuick.split("|||").filter { it.isNotBlank() }
        }

        val cardMap = parseCardMap(prefs[Keys.CONTACT_CALLING_CARDS_JSON])

        DialerSettings(
            language = prefs[Keys.LANGUAGE]?.let { code ->
                AppLanguage.entries.find { it.code == code }
            } ?: AppLanguage.ENGLISH,
            themeMode = prefs[Keys.THEME_MODE]?.let { name ->
                runCatching { ThemeMode.valueOf(name) }.getOrNull()
            } ?: ThemeMode.SYSTEM,
            dialpadTones = prefs[Keys.DIALPAD_TONES] ?: true,
            dialpadVibrate = prefs[Keys.DIALPAD_VIBRATE] ?: true,
            vibrateOnConnect = prefs[Keys.VIBRATE_ON_CONNECT] ?: true,
            simPreference = prefs[Keys.SIM_PREFERENCE]?.let { name ->
                runCatching { SimPreference.valueOf(name) }.getOrNull()
            } ?: SimPreference.ASK_EVERY_TIME,
            sortByLastName = prefs[Keys.SORT_BY_LAST_NAME] ?: false,
            callRecordingEnabled = prefs[Keys.CALL_RECORDING_ENABLED] ?: false,
            recordingAnnouncementMode = prefs[Keys.RECORDING_ANNOUNCEMENT_MODE]?.let { name ->
                runCatching { RecordingAnnouncementMode.valueOf(name) }.getOrNull()
            } ?: RecordingAnnouncementMode.ANNOUNCE_BOTH_SIDES,
            autoRecordMode = prefs[Keys.AUTO_RECORD_MODE]?.let { name ->
                runCatching { AutoRecordMode.valueOf(name) }.getOrNull()
            } ?: AutoRecordMode.MANUAL_ONLY,
            incomingCallGesture = prefs[Keys.INCOMING_CALL_GESTURE]?.let { name ->
                runCatching { IncomingCallGesture.valueOf(name) }.getOrNull()
            } ?: IncomingCallGesture.SWIPE,
            callerIdAndSpamEnabled = prefs[Keys.CALLER_ID_AND_SPAM] ?: true,
            callerIdAnnouncement = prefs[Keys.CALLER_ID_ANNOUNCEMENT]?.let { name ->
                runCatching { CallerIdAnnouncementMode.valueOf(name) }.getOrNull()
            } ?: CallerIdAnnouncementMode.NEVER,
            flipToSilence = prefs[Keys.FLIP_TO_SILENCE] ?: false,
            defaultCallingCardPath = prefs[Keys.DEFAULT_CALLING_CARD_PATH]?.takeIf { File(it).exists() },
            defaultCallingCardStyle = prefs[Keys.DEFAULT_CALLING_CARD_STYLE] ?: 0,
            contactCallingCards = cardMap.filterValues { File(it).exists() },
            blockedNumbers = prefs[Keys.BLOCKED_NUMBERS] ?: emptySet(),
            quickResponses = quickList,
        )
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dialerDataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun setThemeMode(themeMode: ThemeMode) {
        context.dialerDataStore.edit { it[Keys.THEME_MODE] = themeMode.name }
    }

    suspend fun setDialpadTones(enabled: Boolean) {
        context.dialerDataStore.edit { it[Keys.DIALPAD_TONES] = enabled }
    }

    suspend fun setDialpadVibrate(enabled: Boolean) {
        context.dialerDataStore.edit { it[Keys.DIALPAD_VIBRATE] = enabled }
    }

    suspend fun setVibrateOnConnect(enabled: Boolean) {
        context.dialerDataStore.edit { it[Keys.VIBRATE_ON_CONNECT] = enabled }
    }

    suspend fun setSimPreference(preference: SimPreference) {
        context.dialerDataStore.edit { it[Keys.SIM_PREFERENCE] = preference.name }
    }

    suspend fun setSortByLastName(enabled: Boolean) {
        context.dialerDataStore.edit { it[Keys.SORT_BY_LAST_NAME] = enabled }
    }

    suspend fun setCallRecordingEnabled(enabled: Boolean) {
        context.dialerDataStore.edit { it[Keys.CALL_RECORDING_ENABLED] = enabled }
    }

    suspend fun setRecordingAnnouncementMode(mode: RecordingAnnouncementMode) {
        context.dialerDataStore.edit { it[Keys.RECORDING_ANNOUNCEMENT_MODE] = mode.name }
    }

    suspend fun setAutoRecordMode(mode: AutoRecordMode) {
        context.dialerDataStore.edit { it[Keys.AUTO_RECORD_MODE] = mode.name }
    }

    suspend fun setIncomingCallGesture(gesture: IncomingCallGesture) {
        context.dialerDataStore.edit { it[Keys.INCOMING_CALL_GESTURE] = gesture.name }
    }

    suspend fun setCallerIdAndSpamEnabled(enabled: Boolean) {
        context.dialerDataStore.edit { it[Keys.CALLER_ID_AND_SPAM] = enabled }
    }

    suspend fun setCallerIdAnnouncement(mode: CallerIdAnnouncementMode) {
        context.dialerDataStore.edit { it[Keys.CALLER_ID_ANNOUNCEMENT] = mode.name }
    }

    suspend fun setFlipToSilence(enabled: Boolean) {
        context.dialerDataStore.edit { it[Keys.FLIP_TO_SILENCE] = enabled }
    }

    suspend fun setDefaultCallingCardStyle(styleIndex: Int) {
        context.dialerDataStore.edit { it[Keys.DEFAULT_CALLING_CARD_STYLE] = styleIndex }
    }

    suspend fun saveDefaultCallingCardImage(uri: Uri) {
        val localPath = copyCardImageToInternal(uri, "default_card") ?: return
        context.dialerDataStore.edit { it[Keys.DEFAULT_CALLING_CARD_PATH] = localPath }
    }

    suspend fun clearDefaultCallingCardImage() {
        context.dialerDataStore.edit { prefs ->
            prefs[Keys.DEFAULT_CALLING_CARD_PATH]?.let { runCatching { File(it).delete() } }
            prefs.remove(Keys.DEFAULT_CALLING_CARD_PATH)
        }
    }

    suspend fun saveContactCallingCardImage(normalizedPhone: String, uri: Uri) {
        val key = BangladeshTelecomHelper.normalizeDigits(normalizedPhone)
        if (key.isBlank()) return
        val localPath = copyCardImageToInternal(uri, "card_${key.hashCode()}") ?: return
        context.dialerDataStore.edit { prefs ->
            val map = parseCardMap(prefs[Keys.CONTACT_CALLING_CARDS_JSON]).toMutableMap()
            map[key] = localPath
            prefs[Keys.CONTACT_CALLING_CARDS_JSON] = JSONObject(map as Map<*, *>).toString()
        }
    }

    suspend fun removeContactCallingCard(normalizedPhone: String) {
        val key = BangladeshTelecomHelper.normalizeDigits(normalizedPhone)
        context.dialerDataStore.edit { prefs ->
            val map = parseCardMap(prefs[Keys.CONTACT_CALLING_CARDS_JSON]).toMutableMap()
            map.remove(key)?.let { runCatching { File(it).delete() } }
            prefs[Keys.CONTACT_CALLING_CARDS_JSON] = JSONObject(map as Map<*, *>).toString()
        }
    }

    suspend fun saveQuickResponses(list: List<String>) {
        context.dialerDataStore.edit {
            it[Keys.QUICK_RESPONSES] = list.filter { item -> item.isNotBlank() }.joinToString("|||")
        }
    }

    suspend fun blockNumber(rawNumber: String) {
        val normalized = BangladeshTelecomHelper.normalizeDigits(rawNumber)
        if (normalized.isBlank()) return
        context.dialerDataStore.edit { prefs ->
            val current = prefs[Keys.BLOCKED_NUMBERS] ?: emptySet()
            prefs[Keys.BLOCKED_NUMBERS] = current + normalized
        }
    }

    suspend fun unblockNumber(rawNumber: String) {
        val normalized = BangladeshTelecomHelper.normalizeDigits(rawNumber)
        context.dialerDataStore.edit { prefs ->
            val current = prefs[Keys.BLOCKED_NUMBERS] ?: emptySet()
            prefs[Keys.BLOCKED_NUMBERS] = current - normalized - rawNumber
        }
    }

    private suspend fun copyCardImageToInternal(uri: Uri, prefix: String): String? =
        withContext(Dispatchers.IO) {
            runCatching {
                val dir = File(context.filesDir, "calling_cards")
                if (!dir.exists()) dir.mkdirs()
                val outFile = File(dir, "${prefix}_${System.currentTimeMillis()}.jpg")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    outFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
                if (outFile.exists() && outFile.length() > 0L) outFile.absolutePath else null
            }.getOrNull()
        }

    private fun parseCardMap(raw: String?): Map<String, String> {
        if (raw.isNullOrBlank()) return emptyMap()
        return runCatching {
            val obj = JSONObject(raw)
            val result = mutableMapOf<String, String>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = obj.optString(k)
                if (v.isNotBlank()) result[k] = v
            }
            result
        }.getOrDefault(emptyMap())
    }
}
