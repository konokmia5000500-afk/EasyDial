package com.example.data

import android.Manifest
import android.annotation.SuppressLint
import android.app.role.RoleManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.SubscriptionManager
import androidx.core.content.ContextCompat
import com.example.model.CallDirectionType
import com.example.model.CallLogEntry
import com.example.model.ContactEntry
import com.example.model.PermissionStatus
import com.example.model.PhoneNumberEntry
import com.example.model.SimAccountInfo
import com.example.util.BangladeshTelecomHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DevicePhoneRepository(private val context: Context) {

    fun checkPermissions(): PermissionStatus {
        val hasCallPhone = hasPermission(Manifest.permission.CALL_PHONE)
        val hasReadCallLog = hasPermission(Manifest.permission.READ_CALL_LOG)
        val hasReadContacts = hasPermission(Manifest.permission.READ_CONTACTS)
        val hasPhoneState = hasPermission(Manifest.permission.READ_PHONE_STATE)
        val hasRecordAudio = hasPermission(Manifest.permission.RECORD_AUDIO)
        val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
        val isDefault = telecomManager?.defaultDialerPackage == context.packageName

        return PermissionStatus(
            hasPhoneAndCallLog = hasCallPhone && hasReadCallLog,
            hasContacts = hasReadContacts,
            hasPhoneState = hasPhoneState,
            hasRecordAudio = hasRecordAudio,
            isDefaultDialer = isDefault,
        )
    }

    fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun createDefaultDialerIntent(): Intent? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(Context.ROLE_SERVICE) as? RoleManager
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_DIALER) &&
                !roleManager.isRoleHeld(RoleManager.ROLE_DIALER)
            ) {
                roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER)
            } else {
                null
            }
        } else {
            Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).apply {
                putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, context.packageName)
            }
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun loadSimAccounts(): List<SimAccountInfo> = withContext(Dispatchers.IO) {
        val result = mutableListOf<SimAccountInfo>()
        if (!hasPermission(Manifest.permission.READ_PHONE_STATE)) return@withContext result

        val subscriptionManager =
            context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? SubscriptionManager
        val activeSubs = runCatching { subscriptionManager?.activeSubscriptionInfoList }.getOrNull().orEmpty()

        val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
        val accounts = runCatching { telecomManager?.callCapablePhoneAccounts }.getOrNull().orEmpty()

        if (accounts.isNotEmpty()) {
            accounts.forEachIndexed { index, handle ->
                val account = runCatching { telecomManager?.getPhoneAccount(handle) }.getOrNull()
                val matchedSub = activeSubs.getOrNull(index)
                val carrier = matchedSub?.carrierName?.toString()?.takeIf { it.isNotBlank() }
                    ?: account?.label?.toString()?.takeIf { it.isNotBlank() }
                    ?: "SIM ${index + 1}"
                val slotIndex = matchedSub?.simSlotIndex ?: index
                val number = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && matchedSub != null) {
                    runCatching { subscriptionManager?.getPhoneNumber(matchedSub.subscriptionId) }.getOrNull()
                } else {
                    @Suppress("DEPRECATION")
                    matchedSub?.number
                }
                result.add(
                    SimAccountInfo(
                        id = handle.id,
                        slotIndex = slotIndex,
                        displayName = "SIM ${slotIndex + 1}",
                        carrierName = carrier,
                        phoneNumber = number?.takeIf { it.isNotBlank() },
                    )
                )
            }
        } else {
            activeSubs.forEachIndexed { index, sub ->
                result.add(
                    SimAccountInfo(
                        id = sub.subscriptionId.toString(),
                        slotIndex = sub.simSlotIndex,
                        displayName = "SIM ${sub.simSlotIndex + 1}",
                        carrierName = sub.carrierName?.toString() ?: "SIM ${index + 1}",
                        phoneNumber = null,
                    )
                )
            }
        }
        result.sortedBy { it.slotIndex }
    }

    suspend fun loadContacts(sortByLastName: Boolean): List<ContactEntry> = withContext(Dispatchers.IO) {
        if (!hasPermission(Manifest.permission.READ_CONTACTS)) return@withContext emptyList()

        val contactsMap = linkedMapOf<Long, MutableContactBuilder>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.TYPE,
            ContactsContract.CommonDataKinds.Phone.LABEL,
            ContactsContract.CommonDataKinds.Phone.PHOTO_URI,
            ContactsContract.CommonDataKinds.Phone.STARRED,
        )
        val sortColumn = if (sortByLastName) {
            ContactsContract.CommonDataKinds.Phone.SORT_KEY_ALTERNATIVE
        } else {
            ContactsContract.CommonDataKinds.Phone.SORT_KEY_PRIMARY
        }

        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            null,
            null,
            "$sortColumn ASC",
        )?.use { cursor ->
            val idIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val lookupIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY)
            val nameIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY)
            val numberIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val typeIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.TYPE)
            val labelIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.LABEL)
            val photoIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.PHOTO_URI)
            val starredIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.STARRED)

            while (cursor.moveToNext()) {
                val contactId = cursor.getLong(idIdx)
                val lookupKey = cursor.getString(lookupIdx) ?: ""
                val name = cursor.getString(nameIdx)?.trim().orEmpty()
                val rawNumber = cursor.getString(numberIdx)?.trim().orEmpty()
                if (rawNumber.isBlank()) continue
                val type = cursor.getInt(typeIdx)
                val customLabel = cursor.getString(labelIdx)
                val typeLabel = ContactsContract.CommonDataKinds.Phone.getTypeLabel(
                    context.resources,
                    type,
                    customLabel,
                ).toString()
                val photoUri = cursor.getString(photoIdx)
                val isStarred = cursor.getInt(starredIdx) == 1

                val normalized = BangladeshTelecomHelper.normalizeDigits(rawNumber)
                val builder = contactsMap.getOrPut(contactId) {
                    MutableContactBuilder(
                        id = contactId,
                        lookupKey = lookupKey,
                        name = name.ifBlank { rawNumber },
                        photoUri = photoUri,
                        isStarred = isStarred,
                    )
                }
                if (builder.numbers.none { it.normalized == normalized }) {
                    builder.numbers.add(
                        PhoneNumberEntry(
                            number = rawNumber,
                            normalized = normalized,
                            typeLabel = typeLabel,
                        )
                    )
                }
            }
        }

        contactsMap.values.map { it.build() }
    }

    suspend fun loadCallLogs(
        simAccounts: List<SimAccountInfo>,
        contacts: List<ContactEntry> = emptyList(),
    ): List<CallLogEntry> = withContext(Dispatchers.IO) {
        if (!hasPermission(Manifest.permission.READ_CALL_LOG)) return@withContext emptyList()

        val contactByNormalized = HashMap<String, ContactEntry>(contacts.size * 2)
        for (c in contacts) {
            for (n in c.numbers) {
                if (n.normalized.isNotEmpty()) contactByNormalized[n.normalized] = c
            }
        }

        val logs = mutableListOf<CallLogEntry>()
        val projection = arrayOf(
            CallLog.Calls._ID,
            CallLog.Calls.NUMBER,
            CallLog.Calls.CACHED_NAME,
            CallLog.Calls.TYPE,
            CallLog.Calls.DATE,
            CallLog.Calls.DURATION,
            CallLog.Calls.PHONE_ACCOUNT_ID,
            CallLog.Calls.CACHED_PHOTO_URI,
        )

        context.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            projection,
            null,
            null,
            "${CallLog.Calls.DATE} DESC",
        )?.use { cursor ->
            val idIdx = cursor.getColumnIndexOrThrow(CallLog.Calls._ID)
            val numberIdx = cursor.getColumnIndexOrThrow(CallLog.Calls.NUMBER)
            val nameIdx = cursor.getColumnIndexOrThrow(CallLog.Calls.CACHED_NAME)
            val typeIdx = cursor.getColumnIndexOrThrow(CallLog.Calls.TYPE)
            val dateIdx = cursor.getColumnIndexOrThrow(CallLog.Calls.DATE)
            val durationIdx = cursor.getColumnIndexOrThrow(CallLog.Calls.DURATION)
            val accountIdx = cursor.getColumnIndexOrThrow(CallLog.Calls.PHONE_ACCOUNT_ID)
            val photoIdx = cursor.getColumnIndexOrThrow(CallLog.Calls.CACHED_PHOTO_URI)

            var count = 0
            while (cursor.moveToNext() && count < 300) {
                val id = cursor.getLong(idIdx)
                val number = cursor.getString(numberIdx)?.trim().orEmpty()
                val normalized = BangladeshTelecomHelper.normalizeDigits(number)
                val matchedContact = contactByNormalized[normalized]
                val cachedName = cursor.getString(nameIdx)?.trim()?.takeIf { it.isNotEmpty() }
                    ?: matchedContact?.name
                val rawType = cursor.getInt(typeIdx)
                val dateMillis = cursor.getLong(dateIdx)
                val duration = cursor.getLong(durationIdx)
                val accountId = cursor.getString(accountIdx)
                val photoUri = cursor.getString(photoIdx)?.takeIf { it.isNotBlank() }
                    ?: matchedContact?.photoUri

                val direction = when (rawType) {
                    CallLog.Calls.INCOMING_TYPE -> CallDirectionType.INCOMING
                    CallLog.Calls.OUTGOING_TYPE -> CallDirectionType.OUTGOING
                    CallLog.Calls.MISSED_TYPE -> CallDirectionType.MISSED
                    CallLog.Calls.REJECTED_TYPE -> CallDirectionType.REJECTED
                    CallLog.Calls.BLOCKED_TYPE -> CallDirectionType.BLOCKED
                    CallLog.Calls.VOICEMAIL_TYPE -> CallDirectionType.VOICEMAIL
                    else -> CallDirectionType.INCOMING
                }

                val matchedSim = accountId?.let { accId ->
                    simAccounts.find { it.id == accId || accId.contains(it.id) }
                }

                logs.add(
                    CallLogEntry(
                        id = id,
                        number = number,
                        formattedNumber = BangladeshTelecomHelper.formatPhoneNumber(number),
                        cachedName = cachedName,
                        type = direction,
                        dateMillis = dateMillis,
                        durationSeconds = duration,
                        phoneAccountId = accountId,
                        simSlotLabel = matchedSim?.let { "${it.displayName} • ${it.carrierName}" },
                        photoUri = photoUri,
                        carrier = BangladeshTelecomHelper.detectCarrier(number),
                    )
                )
                count++
            }
        }
        logs
    }

    @SuppressLint("MissingPermission")
    fun silenceRinger() {
        val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            @Suppress("DEPRECATION")
            runCatching { telecomManager?.silenceRinger() }
        }
    }

    suspend fun lookupCallerPhotoUri(phoneNumber: String): String? = withContext(Dispatchers.IO) {
        if (phoneNumber.isBlank() || !hasPermission(Manifest.permission.READ_CONTACTS)) {
            return@withContext null
        }
        val lookupUri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(phoneNumber),
        )
        runCatching {
            context.contentResolver.query(
                lookupUri,
                arrayOf(ContactsContract.PhoneLookup.PHOTO_URI),
                null,
                null,
                null,
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    cursor.getString(0)?.takeIf { it.isNotBlank() }
                } else {
                    null
                }
            }
        }.getOrNull()
    }

    suspend fun toggleContactStarred(contactId: Long, starred: Boolean): Boolean = withContext(Dispatchers.IO) {
        if (!hasPermission(Manifest.permission.WRITE_CONTACTS)) return@withContext false
        val values = ContentValues().apply {
            put(ContactsContract.Contacts.STARRED, if (starred) 1 else 0)
        }
        val updated = context.contentResolver.update(
            ContactsContract.Contacts.CONTENT_URI,
            values,
            "${ContactsContract.Contacts._ID} = ?",
            arrayOf(contactId.toString()),
        )
        updated > 0
    }

    suspend fun deleteCallLogEntry(callLogId: Long): Boolean = withContext(Dispatchers.IO) {
        if (!hasPermission(Manifest.permission.WRITE_CALL_LOG)) return@withContext false
        val deleted = context.contentResolver.delete(
            CallLog.Calls.CONTENT_URI,
            "${CallLog.Calls._ID} = ?",
            arrayOf(callLogId.toString()),
        )
        deleted > 0
    }

    suspend fun clearAllCallLogs(): Boolean = withContext(Dispatchers.IO) {
        if (!hasPermission(Manifest.permission.WRITE_CALL_LOG)) return@withContext false
        val deleted = context.contentResolver.delete(CallLog.Calls.CONTENT_URI, null, null)
        deleted >= 0
    }

    @SuppressLint("MissingPermission")
    fun placeCall(number: String, simAccountId: String? = null) {
        val trimmed = number.trim()
        if (trimmed.isEmpty()) return

        // Uri.fromParts properly encodes '#' as '%23' so Bangladeshi USSD codes (*121#, *2#) work!
        val callUri = Uri.fromParts("tel", trimmed, null)

        if (hasPermission(Manifest.permission.CALL_PHONE)) {
            val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            if (telecomManager != null && simAccountId != null && hasPermission(Manifest.permission.READ_PHONE_STATE)) {
                val handle: PhoneAccountHandle? = runCatching {
                    telecomManager.callCapablePhoneAccounts.find { it.id == simAccountId }
                }.getOrNull()
                if (handle != null) {
                    val extras = Bundle().apply {
                        putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, handle)
                    }
                    runCatching {
                        telecomManager.placeCall(callUri, extras)
                        return
                    }
                }
            }
            val callIntent = Intent(Intent.ACTION_CALL, callUri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(callIntent)
        } else {
            val dialIntent = Intent(Intent.ACTION_DIAL, callUri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(dialIntent)
        }
    }

    fun openSmsApp(number: String) {
        val uri = Uri.parse("smsto:${Uri.encode(number)}")
        val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        runCatching { context.startActivity(intent) }
    }

    fun openAddContact(prefillNumber: String? = null) {
        val intent = Intent(ContactsContract.Intents.Insert.ACTION).apply {
            type = ContactsContract.RawContacts.CONTENT_TYPE
            if (!prefillNumber.isNullOrBlank()) {
                putExtra(ContactsContract.Intents.Insert.PHONE, prefillNumber)
            }
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        runCatching { context.startActivity(intent) }
    }

    fun openEditContact(contactId: Long, lookupKey: String) {
        val lookupUri = ContactsContract.Contacts.getLookupUri(contactId, lookupKey)
        val intent = Intent(Intent.ACTION_EDIT).apply {
            setDataAndType(lookupUri, ContactsContract.Contacts.CONTENT_ITEM_TYPE)
            putExtra("finishActivityOnSaveComplete", true)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        runCatching { context.startActivity(intent) }
    }

    fun openSystemCallingAccounts() {
        val intent = Intent(TelecomManager.ACTION_CHANGE_PHONE_ACCOUNTS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        runCatching { context.startActivity(intent) }
    }

    private class MutableContactBuilder(
        val id: Long,
        val lookupKey: String,
        val name: String,
        val photoUri: String?,
        val isStarred: Boolean,
        val numbers: MutableList<PhoneNumberEntry> = mutableListOf(),
    ) {
        fun build(): ContactEntry {
            val primaryNum = numbers.firstOrNull()?.number.orEmpty()
            return ContactEntry(
                id = id,
                lookupKey = lookupKey,
                name = name,
                numbers = numbers.toList(),
                photoUri = photoUri,
                isStarred = isStarred,
                t9NameDigits = BangladeshTelecomHelper.toT9Digits(name),
                primaryCarrier = BangladeshTelecomHelper.detectCarrier(primaryNum),
            )
        }
    }
}
