package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.Dialpad
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Dialpad
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.model.DialerTab
import com.example.ui.DialerViewModel
import com.example.ui.components.GoogleStyleSearchBar
import com.example.ui.components.SimPickerBottomSheet
import com.example.ui.components.UssdDirectoryBottomSheet
import com.example.ui.components.consumeBackgroundTouches
import com.example.ui.screens.BlockedNumbersScreen
import com.example.ui.screens.CallLogDetailBottomSheet
import com.example.ui.screens.CallRecordingSettingsScreen
import com.example.ui.screens.CallRecordingsListScreen
import com.example.ui.screens.CallerIdAnnouncementScreen
import com.example.ui.screens.CallerIdSpamScreen
import com.example.ui.screens.CallingAccountsScreen
import com.example.ui.screens.CallingCardSettingsScreen
import com.example.ui.screens.ContactDetailBottomSheet
import com.example.ui.screens.ContactsScreen
import com.example.ui.screens.DisplayOptionsScreen
import com.example.ui.screens.FlipToSilenceScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.IncomingCallGestureScreen
import com.example.ui.screens.KeypadScreen
import com.example.ui.screens.QuickResponsesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SoundsVibrationScreen
import com.example.ui.theme.AlaapPhoneTheme
import com.example.util.BangladeshTelecomHelper
import com.example.util.LocalizedStrings
import kotlinx.coroutines.launch
import java.util.Locale

const val ROUTE_MAIN = "main"
const val ROUTE_CONTACTS = "contacts"
const val ROUTE_SETTINGS = "settings"
const val ROUTE_CALLER_ID_SPAM = "caller_id_spam"
const val ROUTE_BLOCKED_NUMBERS = "blocked_numbers"
const val ROUTE_CALLING_ACCOUNTS = "calling_accounts"
const val ROUTE_CALL_RECORDING_SETTINGS = "call_recording_settings"
const val ROUTE_RECORDINGS_LIST = "recordings_list"
const val ROUTE_DISPLAY_OPTIONS = "display_options"
const val ROUTE_INCOMING_GESTURE = "incoming_gesture"
const val ROUTE_QUICK_RESPONSES = "quick_responses"
const val ROUTE_SOUNDS_VIBRATION = "sounds_vibration"
const val ROUTE_CALLING_CARD = "calling_card"
const val ROUTE_CALLER_ID_ANNOUNCEMENT = "caller_id_announcement"
const val ROUTE_FLIP_TO_SILENCE = "flip_to_silence"

class MainActivity : ComponentActivity() {

    private val viewModel: DialerViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleDialIntent(intent)

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val strings = LocalizedStrings.forLanguage(uiState.settings.language)
            val navController = rememberNavController()
            val scope = rememberCoroutineScope()
            val context = LocalContext.current
            val snackbarHostState = remember { SnackbarHostState() }

            var showUssdSheet by remember { mutableStateOf(false) }
            var showClearHistorySheet by remember { mutableStateOf(false) }
            var requestedOnce by rememberSaveable { mutableStateOf(false) }
            var isListeningVoice by remember { mutableStateOf(false) }

            val requiredPermissions = remember {
                buildList {
                    add(Manifest.permission.CALL_PHONE)
                    add(Manifest.permission.READ_CALL_LOG)
                    add(Manifest.permission.WRITE_CALL_LOG)
                    add(Manifest.permission.READ_CONTACTS)
                    add(Manifest.permission.WRITE_CONTACTS)
                    add(Manifest.permission.READ_PHONE_STATE)
                    add(Manifest.permission.RECORD_AUDIO)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        add(Manifest.permission.ANSWER_PHONE_CALLS)
                    }
                }.toTypedArray()
            }

            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions(),
            ) {
                viewModel.refreshAllData()
            }

            val micPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission(),
            ) {
                viewModel.refreshAllData()
            }

            val defaultDialerLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.StartActivityForResult(),
            ) {
                viewModel.refreshAllData()
            }

            // Offline Android SpeechRecognizer setup
            val speechRecognizer = remember(context) {
                if (SpeechRecognizer.isRecognitionAvailable(context)) {
                    runCatching { SpeechRecognizer.createSpeechRecognizer(context) }.getOrNull()
                } else {
                    null
                }
            }

            DisposableEffect(speechRecognizer) {
                speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        isListeningVoice = true
                    }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        isListeningVoice = false
                    }
                    override fun onError(error: Int) {
                        isListeningVoice = false
                    }
                    override fun onResults(results: Bundle?) {
                        isListeningVoice = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spoken = matches?.firstOrNull()?.trim().orEmpty()
                        if (spoken.isNotEmpty()) {
                            viewModel.selectTab(DialerTab.HOME)
                            viewModel.updateSearchQuery(spoken)
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spoken = matches?.firstOrNull()?.trim().orEmpty()
                        if (spoken.isNotEmpty()) {
                            viewModel.selectTab(DialerTab.HOME)
                            viewModel.updateSearchQuery(spoken)
                        }
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                onDispose {
                    runCatching { speechRecognizer?.destroy() }
                }
            }

            val voiceFallbackLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.StartActivityForResult(),
            ) { result ->
                val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                val spoken = matches?.firstOrNull()?.trim().orEmpty()
                if (spoken.isNotEmpty()) {
                    viewModel.selectTab(DialerTab.HOME)
                    viewModel.updateSearchQuery(spoken)
                }
            }

            val startOfflineVoiceSearch: () -> Unit = {
                if (isListeningVoice) {
                    runCatching { speechRecognizer?.stopListening() }
                    isListeningVoice = false
                } else {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(
                            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
                        )
                        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                        val langTag = if (uiState.settings.language == com.example.model.AppLanguage.BANGLA) {
                            "bn-BD"
                        } else {
                            Locale.getDefault().toLanguageTag()
                        }
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
                    }
                    if (speechRecognizer != null) {
                        isListeningVoice = true
                        runCatching { speechRecognizer.startListening(intent) }.onFailure {
                            isListeningVoice = false
                            scope.launch { snackbarHostState.showSnackbar(strings.voiceSearchUnavailable) }
                        }
                    } else {
                        runCatching { voiceFallbackLauncher.launch(intent) }.onFailure {
                            scope.launch { snackbarHostState.showSnackbar(strings.voiceSearchUnavailable) }
                        }
                    }
                }
            }

            val voiceMicPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission(),
            ) { granted ->
                viewModel.refreshAllData()
                if (granted) {
                    startOfflineVoiceSearch()
                } else {
                    scope.launch { snackbarHostState.showSnackbar(strings.micPermissionRequired) }
                }
            }

            val onVoiceSearchTriggered: () -> Unit = {
                val hasMic = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO,
                ) == PackageManager.PERMISSION_GRANTED
                if (hasMic) {
                    startOfflineVoiceSearch()
                } else {
                    voiceMicPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }

            LaunchedEffect(Unit) {
                if (!requestedOnce && !uiState.permissions.allCoreGranted) {
                    requestedOnce = true
                    permissionLauncher.launch(requiredPermissions)
                }
            }

            LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
                viewModel.refreshAllData()
            }

            val requestDefaultDialer: () -> Unit = {
                viewModel.createDefaultDialerIntent()?.let { roleIntent ->
                    defaultDialerLauncher.launch(roleIntent)
                }
            }

            AlaapPhoneTheme(themeMode = uiState.settings.themeMode) {
                NavHost(
                    navController = navController,
                    startDestination = ROUTE_MAIN,
                ) {
                    composable(ROUTE_MAIN) {
                        val drawerState = rememberDrawerState(DrawerValue.Closed)
                        BackHandler(enabled = drawerState.isOpen) {
                            scope.launch { drawerState.close() }
                        }

                        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                            val drawerWidth = (maxWidth * 0.64f).coerceIn(240.dp, 276.dp)

                            ModalNavigationDrawer(
                                drawerState = drawerState,
                                scrimColor = Color.Black.copy(alpha = 0.45f),
                                drawerContent = {
                                    ModalDrawerSheet(
                                        modifier = Modifier.width(drawerWidth),
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Start,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(start = 8.dp, end = 16.dp, top = 12.dp, bottom = 12.dp),
                                        ) {
                                            IconButton(
                                                onClick = { scope.launch { drawerState.close() } },
                                                modifier = Modifier.testTag("drawer_close_arrow_button"),
                                            ) {
                                                Icon(
                                                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                                    contentDescription = "Close menu",
                                                    tint = MaterialTheme.colorScheme.onSurface,
                                                )
                                            }
                                            Spacer(Modifier.width(4.dp))
                                            Text(
                                                text = strings.drawerTitle,
                                                style = MaterialTheme.typography.headlineSmall,
                                                fontWeight = FontWeight.Medium,
                                            )
                                        }
                                        HorizontalDivider(modifier = Modifier.padding(bottom = 8.dp))
                                        NavigationDrawerItem(
                                            icon = { Icon(Icons.Rounded.Contacts, contentDescription = null) },
                                            label = { Text(strings.tabContacts) },
                                            selected = false,
                                            onClick = {
                                                scope.launch { drawerState.close() }
                                                navController.navigate(ROUTE_CONTACTS)
                                            },
                                            modifier = Modifier
                                                .padding(horizontal = 10.dp)
                                                .testTag("drawer_contacts_item"),
                                        )
                                        NavigationDrawerItem(
                                            icon = { Icon(Icons.Rounded.Settings, contentDescription = null) },
                                            label = { Text(strings.settings) },
                                            selected = false,
                                            onClick = {
                                                scope.launch { drawerState.close() }
                                                navController.navigate(ROUTE_SETTINGS)
                                            },
                                            modifier = Modifier
                                                .padding(horizontal = 10.dp)
                                                .testTag("drawer_settings_item"),
                                        )
                                        NavigationDrawerItem(
                                            icon = { Icon(Icons.Rounded.GraphicEq, contentDescription = null) },
                                            label = { Text("${strings.recordedCallsTitle} (${uiState.recordings.size})") },
                                            selected = false,
                                            onClick = {
                                                scope.launch { drawerState.close() }
                                                navController.navigate(ROUTE_RECORDINGS_LIST)
                                            },
                                            modifier = Modifier
                                                .padding(horizontal = 10.dp)
                                                .testTag("drawer_recordings_item"),
                                        )
                                        NavigationDrawerItem(
                                            icon = { Icon(Icons.Rounded.Tag, contentDescription = null) },
                                            label = { Text(strings.ussdCodes) },
                                            selected = false,
                                            onClick = {
                                                scope.launch { drawerState.close() }
                                                showUssdSheet = true
                                            },
                                            modifier = Modifier
                                                .padding(horizontal = 10.dp)
                                                .testTag("drawer_ussd_item"),
                                        )
                                        if (uiState.callLogs.isNotEmpty()) {
                                            NavigationDrawerItem(
                                                icon = { Icon(Icons.Rounded.DeleteSweep, contentDescription = null) },
                                                label = { Text(strings.clearCallHistory) },
                                                selected = false,
                                                onClick = {
                                                    scope.launch { drawerState.close() }
                                                    showClearHistorySheet = true
                                                },
                                                modifier = Modifier
                                                    .padding(horizontal = 10.dp)
                                                    .testTag("drawer_clear_history_item"),
                                            )
                                        }
                                    }
                                },
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.background,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .consumeBackgroundTouches(),
                                ) {
                                MainDialerScreen(
                                    uiState = uiState,
                                    strings = strings,
                                    isListeningVoice = isListeningVoice,
                                    snackbarHostState = snackbarHostState,
                                    onSelectTab = viewModel::selectTab,
                                    onSearchQueryChange = { q ->
                                        viewModel.updateSearchQuery(q)
                                        if (q.isNotBlank() && uiState.selectedTab != DialerTab.HOME) {
                                            viewModel.selectTab(DialerTab.HOME)
                                        }
                                    },
                                    onOpenDrawer = { scope.launch { drawerState.open() } },
                                    onVoiceSearchClick = onVoiceSearchTriggered,
                                    onToggleFavoritesExpanded = viewModel::toggleFavoritesExpanded,
                                    onViewContacts = { navController.navigate(ROUTE_CONTACTS) },
                                    onSelectRecentsFilter = viewModel::selectRecentsFilter,
                                    onSelectDialerSimIndex = viewModel::selectDialerSim,
                                    onDigitClick = viewModel::appendDialpadDigit,
                                    onBackspace = viewModel::backspaceDialpad,
                                    onClearAllDigits = viewModel::clearDialpad,
                                    onCallNumber = { number, useKeypadSim ->
                                        viewModel.initiateCall(number, useSelectedKeypadSim = useKeypadSim)
                                    },
                                    onOpenCallDetail = viewModel::openCallLogDetail,
                                    onOpenContactDetail = viewModel::openContactDetail,
                                    onCreateNewContact = { number -> viewModel.openAddContact(number) },
                                    onOpenUssdCodes = { showUssdSheet = true },
                                    onRequestPermissions = { permissionLauncher.launch(requiredPermissions) },
                                    onSetDefaultDialer = requestDefaultDialer,
                                )
                            }
                        }
                        }
                    }

                    composable(ROUTE_CONTACTS) {
                        ContactsScreen(
                            contacts = uiState.contacts,
                            contactCallingCards = uiState.settings.contactCallingCards,
                            permissions = uiState.permissions,
                            language = uiState.settings.language,
                            strings = strings,
                            onBack = { navController.popBackStack() },
                            onCallNumber = { num -> viewModel.initiateCall(num) },
                            onOpenContactDetail = viewModel::openContactDetail,
                            onCreateNewContact = { viewModel.openAddContact() },
                            onRequestPermissions = { permissionLauncher.launch(requiredPermissions) },
                        )
                    }

                    composable(ROUTE_SETTINGS) {
                        SettingsScreen(
                            settings = uiState.settings,
                            permissions = uiState.permissions,
                            simAccounts = uiState.simAccounts,
                            recordingsCount = uiState.recordings.size,
                            strings = strings,
                            onBack = { navController.popBackStack() },
                            onSetDefaultDialer = requestDefaultDialer,
                            onOpenCallerIdSpam = { navController.navigate(ROUTE_CALLER_ID_SPAM) },
                            onOpenBlockedNumbers = { navController.navigate(ROUTE_BLOCKED_NUMBERS) },
                            onOpenCallingAccounts = { navController.navigate(ROUTE_CALLING_ACCOUNTS) },
                            onOpenCallRecordingSettings = { navController.navigate(ROUTE_CALL_RECORDING_SETTINGS) },
                            onOpenDisplayOptions = { navController.navigate(ROUTE_DISPLAY_OPTIONS) },
                            onOpenIncomingGesture = { navController.navigate(ROUTE_INCOMING_GESTURE) },
                            onOpenQuickResponses = { navController.navigate(ROUTE_QUICK_RESPONSES) },
                            onOpenSoundsVibration = { navController.navigate(ROUTE_SOUNDS_VIBRATION) },
                            onOpenCallingCard = { navController.navigate(ROUTE_CALLING_CARD) },
                            onOpenCallerIdAnnouncement = { navController.navigate(ROUTE_CALLER_ID_ANNOUNCEMENT) },
                            onOpenFlipToSilence = { navController.navigate(ROUTE_FLIP_TO_SILENCE) },
                            onOpenUssdDirectory = { showUssdSheet = true },
                        )
                    }

                    composable(ROUTE_CALLER_ID_SPAM) {
                        CallerIdSpamScreen(
                            enabled = uiState.settings.callerIdAndSpamEnabled,
                            strings = strings,
                            onBack = { navController.popBackStack() },
                            onToggleEnabled = viewModel::setCallerIdAndSpamEnabled,
                        )
                    }

                    composable(ROUTE_BLOCKED_NUMBERS) {
                        BlockedNumbersScreen(
                            blockedNumbers = uiState.settings.blockedNumbers,
                            strings = strings,
                            onBack = { navController.popBackStack() },
                            onBlockNumber = viewModel::blockNumber,
                            onUnblockNumber = viewModel::unblockNumber,
                        )
                    }

                    composable(ROUTE_CALLING_ACCOUNTS) {
                        CallingAccountsScreen(
                            simPreference = uiState.settings.simPreference,
                            simAccounts = uiState.simAccounts,
                            strings = strings,
                            onBack = { navController.popBackStack() },
                            onSimPreferenceChange = viewModel::setSimPreference,
                            onOpenSystemCallingAccounts = viewModel::openSystemCallingAccounts,
                        )
                    }

                    composable(ROUTE_CALL_RECORDING_SETTINGS) {
                        CallRecordingSettingsScreen(
                            settings = uiState.settings,
                            hasMicPermission = uiState.permissions.hasRecordAudio,
                            recordingsCount = uiState.recordings.size,
                            strings = strings,
                            onBack = { navController.popBackStack() },
                            onRequestMicPermission = {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            },
                            onToggleEnabled = viewModel::setCallRecordingEnabled,
                            onSelectAnnouncementMode = viewModel::setRecordingAnnouncementMode,
                            onSelectAutoRecordMode = viewModel::setAutoRecordMode,
                            onOpenRecordingsLibrary = {
                                navController.navigate(ROUTE_RECORDINGS_LIST)
                            },
                        )
                    }

                    composable(ROUTE_RECORDINGS_LIST) {
                        CallRecordingsListScreen(
                            recordings = uiState.recordings,
                            strings = strings,
                            onBack = { navController.popBackStack() },
                            onDeleteRecording = viewModel::deleteRecording,
                        )
                    }

                    composable(ROUTE_DISPLAY_OPTIONS) {
                        DisplayOptionsScreen(
                            settings = uiState.settings,
                            strings = strings,
                            onBack = { navController.popBackStack() },
                            onLanguageChange = viewModel::setLanguage,
                            onThemeModeChange = viewModel::setThemeMode,
                            onSortByLastNameChange = viewModel::setSortByLastName,
                        )
                    }

                    composable(ROUTE_INCOMING_GESTURE) {
                        IncomingCallGestureScreen(
                            selectedGesture = uiState.settings.incomingCallGesture,
                            strings = strings,
                            onBack = { navController.popBackStack() },
                            onSelectGesture = viewModel::setIncomingCallGesture,
                        )
                    }

                    composable(ROUTE_QUICK_RESPONSES) {
                        QuickResponsesScreen(
                            responses = uiState.settings.quickResponses,
                            strings = strings,
                            onBack = { navController.popBackStack() },
                            onSaveResponses = viewModel::saveQuickResponses,
                        )
                    }

                    composable(ROUTE_SOUNDS_VIBRATION) {
                        SoundsVibrationScreen(
                            settings = uiState.settings,
                            strings = strings,
                            onBack = { navController.popBackStack() },
                            onDialpadTonesChange = viewModel::setDialpadTones,
                            onDialpadVibrateChange = viewModel::setDialpadVibrate,
                            onVibrateOnConnectChange = viewModel::setVibrateOnConnect,
                        )
                    }

                    composable(ROUTE_CALLING_CARD) {
                        CallingCardSettingsScreen(
                            settings = uiState.settings,
                            contacts = uiState.contacts,
                            strings = strings,
                            onBack = { navController.popBackStack() },
                            onSelectDefaultStyle = viewModel::setDefaultCallingCardStyle,
                            onPickDefaultPhoto = viewModel::saveDefaultCallingCardImage,
                            onClearDefaultPhoto = viewModel::clearDefaultCallingCardImage,
                            onPickContactPhoto = viewModel::saveContactCallingCardImage,
                            onRemoveContactPhoto = viewModel::removeContactCallingCard,
                        )
                    }

                    composable(ROUTE_CALLER_ID_ANNOUNCEMENT) {
                        CallerIdAnnouncementScreen(
                            mode = uiState.settings.callerIdAnnouncement,
                            strings = strings,
                            onBack = { navController.popBackStack() },
                            onSelectMode = viewModel::setCallerIdAnnouncement,
                        )
                    }

                    composable(ROUTE_FLIP_TO_SILENCE) {
                        FlipToSilenceScreen(
                            enabled = uiState.settings.flipToSilence,
                            strings = strings,
                            onBack = { navController.popBackStack() },
                            onToggleEnabled = viewModel::setFlipToSilence,
                        )
                    }
                }

                uiState.pendingSimChoiceNumber?.let { pendingNum ->
                    SimPickerBottomSheet(
                        number = pendingNum,
                        simAccounts = uiState.simAccounts,
                        strings = strings,
                        onSelectSim = viewModel::confirmSimAndCall,
                        onDismiss = viewModel::dismissSimPicker,
                    )
                }

                uiState.selectedContactForDetail?.let { contact ->
                    val primaryNum = contact.numbers.firstOrNull()?.number.orEmpty()
                    val cardPath = uiState.settings.contactCallingCards[
                        BangladeshTelecomHelper.normalizeDigits(primaryNum)
                    ]
                    ContactDetailBottomSheet(
                        contact = contact,
                        callingCardPath = cardPath,
                        language = uiState.settings.language,
                        strings = strings,
                        onCallNumber = { num -> viewModel.initiateCall(num) },
                        onMessageNumber = viewModel::openSms,
                        onToggleStarred = viewModel::toggleStarred,
                        onEditContact = viewModel::openEditContact,
                        onSetCallingCard = viewModel::saveContactCallingCardImage,
                        onBlockNumber = viewModel::blockNumber,
                        onDismiss = { viewModel.openContactDetail(null) },
                    )
                }

                uiState.selectedCallLogForDetail?.let { group ->
                    val cardPath = uiState.settings.contactCallingCards[
                        BangladeshTelecomHelper.normalizeDigits(group.primary.number)
                    ]
                    CallLogDetailBottomSheet(
                        group = group,
                        callingCardPath = cardPath,
                        language = uiState.settings.language,
                        strings = strings,
                        onCall = { num -> viewModel.initiateCall(num) },
                        onMessage = viewModel::openSms,
                        onAddToContacts = { num -> viewModel.openAddContact(num) },
                        onBlockNumber = viewModel::blockNumber,
                        onDeleteGroup = viewModel::deleteCallLogGroup,
                        onDismiss = { viewModel.openCallLogDetail(null) },
                    )
                }

                if (showUssdSheet) {
                    UssdDirectoryBottomSheet(
                        language = uiState.settings.language,
                        strings = strings,
                        onDialCode = { code -> viewModel.initiateCall(code) },
                        onDismiss = { showUssdSheet = false },
                    )
                }

                if (showClearHistorySheet) {
                    ModalBottomSheet(onDismissRequest = { showClearHistorySheet = false }) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp, vertical = 12.dp),
                        ) {
                            Text(
                                text = strings.clearCallHistory,
                                style = MaterialTheme.typography.titleLarge,
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = strings.clearCallHistoryConfirm,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Spacer(Modifier.height(20.dp))
                            Row(modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(
                                    onClick = { showClearHistorySheet = false },
                                    modifier = Modifier.weight(1f),
                                ) {
                                    Text(strings.cancel)
                                }
                                Spacer(Modifier.width(12.dp))
                                Button(
                                    onClick = {
                                        showClearHistorySheet = false
                                        viewModel.clearAllCallLogs()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.error,
                                        contentColor = MaterialTheme.colorScheme.onError,
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("confirm_clear_history_button"),
                                ) {
                                    Text(strings.delete)
                                }
                            }
                            Spacer(Modifier.height(16.dp))
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleDialIntent(intent)
    }

    private fun handleDialIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action
        if (action == Intent.ACTION_DIAL || action == Intent.ACTION_VIEW || action == Intent.ACTION_CALL_BUTTON) {
            val data: Uri? = intent.data
            val prefill = if (data?.scheme == "tel") data.schemeSpecificPart.orEmpty() else ""
            viewModel.showKeypad(prefill)
        }
    }
}

@Composable
private fun MainDialerScreen(
    uiState: com.example.ui.DialerUiState,
    strings: com.example.util.AppStrings,
    isListeningVoice: Boolean,
    snackbarHostState: SnackbarHostState,
    onSelectTab: (DialerTab) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onOpenDrawer: () -> Unit,
    onVoiceSearchClick: () -> Unit,
    onToggleFavoritesExpanded: () -> Unit,
    onViewContacts: () -> Unit,
    onSelectRecentsFilter: (com.example.model.RecentsFilter) -> Unit,
    onSelectDialerSimIndex: (Int) -> Unit,
    onDigitClick: (String) -> Unit,
    onBackspace: () -> Unit,
    onClearAllDigits: () -> Unit,
    onCallNumber: (String, Boolean) -> Unit,
    onOpenCallDetail: (com.example.model.GroupedCallLogItem) -> Unit,
    onOpenContactDetail: (com.example.model.ContactEntry) -> Unit,
    onCreateNewContact: (String) -> Unit,
    onOpenUssdCodes: () -> Unit,
    onRequestPermissions: () -> Unit,
    onSetDefaultDialer: () -> Unit,
) {
    val navItems = listOf(
        Triple(DialerTab.HOME, strings.tabHome, Icons.Rounded.Home to Icons.Outlined.Home),
        Triple(DialerTab.KEYPAD, strings.tabKeypad, Icons.Rounded.Dialpad to Icons.Outlined.Dialpad),
    )

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!useNavRail) {
                    NavigationBar {
                        navItems.forEach { (tab, label, icons) ->
                            val selected = uiState.selectedTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { onSelectTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) icons.first else icons.second,
                                        contentDescription = label,
                                    )
                                },
                                label = { Text(label) },
                                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}"),
                            )
                        }
                    }
                }
            },
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
            ) {
                if (useNavRail) {
                    NavigationRail {
                        navItems.forEach { (tab, label, icons) ->
                            val selected = uiState.selectedTab == tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { onSelectTab(tab) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) icons.first else icons.second,
                                        contentDescription = label,
                                    )
                                },
                                label = { Text(label) },
                                modifier = Modifier.testTag("rail_tab_${tab.name.lowercase()}"),
                            )
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding(),
                ) {
                    GoogleStyleSearchBar(
                        query = uiState.searchQuery,
                        isListeningVoice = isListeningVoice,
                        onQueryChange = onSearchQueryChange,
                        onOpenDrawer = onOpenDrawer,
                        onVoiceSearchClick = onVoiceSearchClick,
                        strings = strings,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    )

                    Box(modifier = Modifier.weight(1f)) {
                        when (uiState.selectedTab) {
                            DialerTab.HOME -> HomeScreen(
                                favorites = uiState.favoriteContacts,
                                favoritesExpanded = uiState.favoritesExpanded,
                                groupedCallLogs = uiState.groupedCallLogs,
                                matchedSearchContacts = uiState.filteredContacts,
                                searchQuery = uiState.searchQuery,
                                selectedFilter = uiState.recentsFilter,
                                callerIdEnabled = uiState.settings.callerIdAndSpamEnabled,
                                contactCallingCards = uiState.settings.contactCallingCards,
                                permissions = uiState.permissions,
                                language = uiState.settings.language,
                                strings = strings,
                                onToggleFavoritesExpanded = onToggleFavoritesExpanded,
                                onViewContacts = onViewContacts,
                                onSelectFilter = onSelectRecentsFilter,
                                onCallNumber = { num -> onCallNumber(num, false) },
                                onOpenCallDetail = onOpenCallDetail,
                                onOpenContactDetail = onOpenContactDetail,
                                onRequestPermissions = onRequestPermissions,
                                onSetDefaultDialer = onSetDefaultDialer,
                            )

                            DialerTab.KEYPAD -> KeypadScreen(
                                digits = uiState.dialpadDigits,
                                suggestions = uiState.t9Suggestions,
                                simAccounts = uiState.simAccounts,
                                selectedSimIndex = uiState.selectedDialerSimIndex,
                                dialpadTonesEnabled = uiState.settings.dialpadTones,
                                dialpadVibrateEnabled = uiState.settings.dialpadVibrate,
                                language = uiState.settings.language,
                                strings = strings,
                                onSelectSimIndex = onSelectDialerSimIndex,
                                onDigitClick = onDigitClick,
                                onBackspace = onBackspace,
                                onClearAll = onClearAllDigits,
                                onCall = { number, useKeypadSim -> onCallNumber(number, useKeypadSim) },
                                onAddContact = onCreateNewContact,
                                onOpenUssdCodes = onOpenUssdCodes,
                            )
                        }
                    }
                }
            }
        }
    }
}
