package com.example.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DevicePhoneRepository
import com.example.data.SettingsRepository
import com.example.model.AppLanguage
import com.example.model.AutoRecordMode
import com.example.model.CallLogEntry
import com.example.model.CallRecordingItem
import com.example.model.CallerIdAnnouncementMode
import com.example.model.ContactEntry
import com.example.model.DialerSettings
import com.example.model.DialerTab
import com.example.model.GroupedCallLogItem
import com.example.model.IncomingCallGesture
import com.example.model.PermissionStatus
import com.example.model.RecentsFilter
import com.example.model.RecordingAnnouncementMode
import com.example.model.SimAccountInfo
import com.example.model.SimPreference
import com.example.model.ThemeMode
import com.example.telecom.CallRecordingManager
import com.example.util.BangladeshTelecomHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class T9Suggestion(
    val id: String,
    val displayName: String,
    val number: String,
    val formattedNumber: String,
    val photoUri: String?,
    val callingCardPath: String?,
    val isSavedContact: Boolean,
    val matchedQuery: String,
)

data class DialerUiState(
    val selectedTab: DialerTab = DialerTab.HOME,
    val searchQuery: String = "",
    val recentsFilter: RecentsFilter = RecentsFilter.ALL,
    val favoritesExpanded: Boolean = true,
    val dialpadDigits: String = "",
    val selectedDialerSimIndex: Int = 0,
    val contacts: List<ContactEntry> = emptyList(),
    val favoriteContacts: List<ContactEntry> = emptyList(),
    val callLogs: List<CallLogEntry> = emptyList(),
    val groupedCallLogs: List<GroupedCallLogItem> = emptyList(),
    val filteredContacts: List<ContactEntry> = emptyList(),
    val t9Suggestions: List<T9Suggestion> = emptyList(),
    val simAccounts: List<SimAccountInfo> = emptyList(),
    val recordings: List<CallRecordingItem> = emptyList(),
    val permissions: PermissionStatus = PermissionStatus(),
    val settings: DialerSettings = DialerSettings(),
    val isLoading: Boolean = false,
    val pendingSimChoiceNumber: String? = null,
    val selectedContactForDetail: ContactEntry? = null,
    val selectedCallLogForDetail: GroupedCallLogItem? = null,
)

class DialerViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val phoneRepo = DevicePhoneRepository(appContext)
    private val settingsRepo = SettingsRepository(appContext)

    private val selectedTab = MutableStateFlow(DialerTab.HOME)
    private val searchQuery = MutableStateFlow("")
    private val recentsFilter = MutableStateFlow(RecentsFilter.ALL)
    private val favoritesExpanded = MutableStateFlow(true)
    private val dialpadDigits = MutableStateFlow("")
    private val selectedDialerSimIndex = MutableStateFlow(0)
    private val contacts = MutableStateFlow<List<ContactEntry>>(emptyList())
    private val callLogs = MutableStateFlow<List<CallLogEntry>>(emptyList())
    private val simAccounts = MutableStateFlow<List<SimAccountInfo>>(emptyList())
    private val recordings = MutableStateFlow<List<CallRecordingItem>>(emptyList())
    private val permissions = MutableStateFlow(phoneRepo.checkPermissions())
    private val isLoading = MutableStateFlow(false)
    private val pendingSimChoiceNumber = MutableStateFlow<String?>(null)
    private val selectedContactForDetail = MutableStateFlow<ContactEntry?>(null)
    private val selectedCallLogForDetail = MutableStateFlow<GroupedCallLogItem?>(null)

    private val settingsFlow = settingsRepo.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DialerSettings(),
    )

    val uiState: StateFlow<DialerUiState> = combine(
        combine(
            selectedTab,
            searchQuery,
            recentsFilter,
            favoritesExpanded,
            dialpadDigits,
        ) { tab, q, filter, favExp, dpDigits ->
            NavFilterState(tab, q, filter, favExp, dpDigits)
        },
        combine(
            contacts,
            callLogs,
            simAccounts,
            permissions,
            isLoading,
        ) { c, l, sims, perms, loading ->
            DataState(c, l, sims, perms, loading)
        },
        combine(
            settingsFlow,
            pendingSimChoiceNumber,
            selectedContactForDetail,
            selectedCallLogForDetail,
            recordings,
        ) { s, simNum, contactDetail, logDetail, recs ->
            OverlayState(s, simNum, contactDetail, logDetail, recs)
        },
        selectedDialerSimIndex,
    ) { nav, data, overlay, simIdx ->
        val queryTrimmed = nav.searchQuery.trim()
        val blockedSet = overlay.settings.blockedNumbers

        val visibleLogs = data.callLogs.filter { entry ->
            BangladeshTelecomHelper.normalizeDigits(entry.number) !in blockedSet
        }

        val filteredLogs = visibleLogs.filter { entry ->
            val matchesFilter = when (nav.recentsFilter) {
                RecentsFilter.ALL -> true
                RecentsFilter.MISSED -> entry.type == com.example.model.CallDirectionType.MISSED ||
                    entry.type == com.example.model.CallDirectionType.REJECTED
                RecentsFilter.CONTACTS -> !entry.cachedName.isNullOrBlank()
                RecentsFilter.OUTGOING -> entry.type == com.example.model.CallDirectionType.OUTGOING
                RecentsFilter.INCOMING -> entry.type == com.example.model.CallDirectionType.INCOMING
            }
            val matchesSearch = if (queryTrimmed.isEmpty()) {
                true
            } else {
                entry.cachedName?.contains(queryTrimmed, ignoreCase = true) == true ||
                    entry.number.contains(queryTrimmed, ignoreCase = true) ||
                    entry.carrier?.nameEn?.contains(queryTrimmed, ignoreCase = true) == true
            }
            matchesFilter && matchesSearch
        }

        val groupedLogs = groupConsecutiveLogs(filteredLogs)

        val filteredContacts = data.contacts.filter { contact ->
            if (queryTrimmed.isEmpty()) {
                true
            } else {
                contact.name.contains(queryTrimmed, ignoreCase = true) ||
                    contact.numbers.any {
                        it.number.contains(queryTrimmed, ignoreCase = true) ||
                            it.normalized.contains(queryTrimmed)
                    }
            }
        }

        val favs = data.contacts.filter { it.isStarred }
        val suggestions = buildT9Suggestions(
            digits = nav.dialpadDigits,
            allContacts = data.contacts,
            allLogs = visibleLogs,
            callingCards = overlay.settings.contactCallingCards,
        )

        DialerUiState(
            selectedTab = nav.tab,
            searchQuery = nav.searchQuery,
            recentsFilter = nav.recentsFilter,
            favoritesExpanded = nav.favoritesExpanded,
            dialpadDigits = nav.dialpadDigits,
            selectedDialerSimIndex = simIdx.coerceIn(0, (data.simAccounts.size - 1).coerceAtLeast(0)),
            contacts = data.contacts,
            favoriteContacts = favs,
            callLogs = visibleLogs,
            groupedCallLogs = groupedLogs,
            filteredContacts = filteredContacts,
            t9Suggestions = suggestions,
            simAccounts = data.simAccounts,
            recordings = overlay.recordings,
            permissions = data.permissions,
            settings = overlay.settings,
            isLoading = data.isLoading,
            pendingSimChoiceNumber = overlay.pendingSimNumber,
            selectedContactForDetail = overlay.contactDetail,
            selectedCallLogForDetail = overlay.logDetail,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DialerUiState(),
    )

    init {
        refreshAllData()
    }

    fun refreshAllData() {
        viewModelScope.launch {
            val currentPerms = phoneRepo.checkPermissions()
            permissions.value = currentPerms
            isLoading.value = true

            val sims = phoneRepo.loadSimAccounts()
            simAccounts.value = sims

            val sortByLast = settingsFlow.value.sortByLastName
            val loadedContacts = if (currentPerms.hasContacts) {
                phoneRepo.loadContacts(sortByLast)
            } else {
                emptyList()
            }
            if (currentPerms.hasContacts) {
                contacts.value = loadedContacts
            }
            if (currentPerms.hasPhoneAndCallLog) {
                callLogs.value = phoneRepo.loadCallLogs(sims, loadedContacts)
            }
            recordings.value = CallRecordingManager.loadRecordings(appContext)
            isLoading.value = false
        }
    }

    fun deleteRecording(filePath: String) {
        viewModelScope.launch {
            CallRecordingManager.deleteRecording(filePath)
            recordings.value = CallRecordingManager.loadRecordings(appContext)
        }
    }

    fun selectTab(tab: DialerTab) {
        selectedTab.value = tab
    }

    fun updateSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun selectRecentsFilter(filter: RecentsFilter) {
        recentsFilter.value = filter
    }

    fun toggleFavoritesExpanded() {
        favoritesExpanded.value = !favoritesExpanded.value
    }

    fun showKeypad(prefill: String? = null) {
        if (prefill != null) {
            dialpadDigits.value = prefill
        }
        selectedTab.value = DialerTab.KEYPAD
    }

    fun cycleDialerSim() {
        val count = simAccounts.value.size
        if (count > 1) {
            selectedDialerSimIndex.value = (selectedDialerSimIndex.value + 1) % count
        }
    }

    fun selectDialerSim(index: Int) {
        selectedDialerSimIndex.value = index
    }

    fun appendDialpadDigit(digit: String) {
        dialpadDigits.value += digit
    }

    fun backspaceDialpad() {
        val current = dialpadDigits.value
        if (current.isNotEmpty()) {
            dialpadDigits.value = current.dropLast(1)
        }
    }

    fun clearDialpad() {
        dialpadDigits.value = ""
    }

    fun initiateCall(number: String, useSelectedKeypadSim: Boolean = false, forceAskSim: Boolean = false) {
        val trimmed = number.trim()
        if (trimmed.isEmpty()) return

        val sims = simAccounts.value
        val simPref = settingsFlow.value.simPreference

        if (useSelectedKeypadSim && sims.isNotEmpty() && !forceAskSim) {
            val chosen = sims.getOrNull(selectedDialerSimIndex.value) ?: sims.first()
            phoneRepo.placeCall(trimmed, chosen.id)
            return
        }

        if (sims.size > 1 && (forceAskSim || simPref == SimPreference.ASK_EVERY_TIME)) {
            pendingSimChoiceNumber.value = trimmed
            return
        }

        val chosenSimId = when {
            sims.size <= 1 -> sims.firstOrNull()?.id
            simPref == SimPreference.SIM_1 -> sims.getOrNull(0)?.id
            simPref == SimPreference.SIM_2 -> sims.getOrNull(1)?.id
            else -> null
        }
        phoneRepo.placeCall(trimmed, chosenSimId)
    }

    fun confirmSimAndCall(simId: String) {
        val number = pendingSimChoiceNumber.value ?: return
        pendingSimChoiceNumber.value = null
        phoneRepo.placeCall(number, simId)
    }

    fun dismissSimPicker() {
        pendingSimChoiceNumber.value = null
    }

    fun openContactDetail(contact: ContactEntry?) {
        selectedContactForDetail.value = contact
    }

    fun openCallLogDetail(item: GroupedCallLogItem?) {
        selectedCallLogForDetail.value = item
    }

    fun toggleStarred(contact: ContactEntry) {
        viewModelScope.launch {
            val newStarred = !contact.isStarred
            if (phoneRepo.toggleContactStarred(contact.id, newStarred)) {
                contacts.value = contacts.value.map {
                    if (it.id == contact.id) it.copy(isStarred = newStarred) else it
                }
                if (selectedContactForDetail.value?.id == contact.id) {
                    selectedContactForDetail.value = contact.copy(isStarred = newStarred)
                }
            }
        }
    }

    fun deleteCallLogGroup(group: GroupedCallLogItem) {
        viewModelScope.launch {
            var anyDeleted = false
            group.entries.forEach { entry ->
                if (phoneRepo.deleteCallLogEntry(entry.id)) anyDeleted = true
            }
            if (anyDeleted) {
                val deletedIds = group.entries.map { it.id }.toSet()
                callLogs.value = callLogs.value.filterNot { it.id in deletedIds }
                selectedCallLogForDetail.value = null
            }
        }
    }

    fun clearAllCallLogs() {
        viewModelScope.launch {
            if (phoneRepo.clearAllCallLogs()) {
                callLogs.value = emptyList()
            }
        }
    }

    fun blockNumber(number: String) {
        viewModelScope.launch {
            settingsRepo.blockNumber(number)
            selectedCallLogForDetail.value = null
            selectedContactForDetail.value = null
        }
    }

    fun unblockNumber(number: String) {
        viewModelScope.launch {
            settingsRepo.unblockNumber(number)
        }
    }

    fun openSms(number: String) = phoneRepo.openSmsApp(number)

    fun openAddContact(prefillNumber: String? = null) = phoneRepo.openAddContact(prefillNumber)

    fun openEditContact(contact: ContactEntry) = phoneRepo.openEditContact(contact.id, contact.lookupKey)

    fun openSystemCallingAccounts() = phoneRepo.openSystemCallingAccounts()

    fun createDefaultDialerIntent(): Intent? = phoneRepo.createDefaultDialerIntent()

    // Settings updates
    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch { settingsRepo.setLanguage(language) }
    }

    fun setThemeMode(themeMode: ThemeMode) {
        viewModelScope.launch { settingsRepo.setThemeMode(themeMode) }
    }

    fun setDialpadTones(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setDialpadTones(enabled) }
    }

    fun setDialpadVibrate(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setDialpadVibrate(enabled) }
    }

    fun setVibrateOnConnect(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setVibrateOnConnect(enabled) }
    }

    fun setSimPreference(preference: SimPreference) {
        viewModelScope.launch { settingsRepo.setSimPreference(preference) }
    }

    fun setSortByLastName(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepo.setSortByLastName(enabled)
            if (permissions.value.hasContacts) {
                contacts.value = phoneRepo.loadContacts(enabled)
            }
        }
    }

    fun setCallRecordingEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setCallRecordingEnabled(enabled) }
    }

    fun setRecordingAnnouncementMode(mode: RecordingAnnouncementMode) {
        viewModelScope.launch { settingsRepo.setRecordingAnnouncementMode(mode) }
    }

    fun setAutoRecordMode(mode: AutoRecordMode) {
        viewModelScope.launch { settingsRepo.setAutoRecordMode(mode) }
    }

    fun setIncomingCallGesture(gesture: IncomingCallGesture) {
        viewModelScope.launch { settingsRepo.setIncomingCallGesture(gesture) }
    }

    fun setCallerIdAndSpamEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setCallerIdAndSpamEnabled(enabled) }
    }

    fun setCallerIdAnnouncement(mode: CallerIdAnnouncementMode) {
        viewModelScope.launch { settingsRepo.setCallerIdAnnouncement(mode) }
    }

    fun setFlipToSilence(enabled: Boolean) {
        viewModelScope.launch { settingsRepo.setFlipToSilence(enabled) }
    }

    fun setDefaultCallingCardStyle(styleIndex: Int) {
        viewModelScope.launch { settingsRepo.setDefaultCallingCardStyle(styleIndex) }
    }

    fun saveDefaultCallingCardImage(uri: Uri) {
        viewModelScope.launch { settingsRepo.saveDefaultCallingCardImage(uri) }
    }

    fun clearDefaultCallingCardImage() {
        viewModelScope.launch { settingsRepo.clearDefaultCallingCardImage() }
    }

    fun saveContactCallingCardImage(phoneNumber: String, uri: Uri) {
        viewModelScope.launch { settingsRepo.saveContactCallingCardImage(phoneNumber, uri) }
    }

    fun removeContactCallingCard(phoneNumber: String) {
        viewModelScope.launch { settingsRepo.removeContactCallingCard(phoneNumber) }
    }

    fun saveQuickResponses(list: List<String>) {
        viewModelScope.launch { settingsRepo.saveQuickResponses(list) }
    }

    private fun groupConsecutiveLogs(logs: List<CallLogEntry>): List<GroupedCallLogItem> {
        if (logs.isEmpty()) return emptyList()
        val result = mutableListOf<GroupedCallLogItem>()
        var currentGroup = mutableListOf(logs.first())
        for (i in 1 until logs.size) {
            val prev = currentGroup.first()
            val curr = logs[i]
            val sameNumber = BangladeshTelecomHelper.normalizeDigits(prev.number) ==
                BangladeshTelecomHelper.normalizeDigits(curr.number)
            val sameDirection = prev.type == curr.type
            val closeInTime = kotlin.math.abs(prev.dateMillis - curr.dateMillis) < 24 * 60 * 60 * 1000L
            if (sameNumber && sameDirection && closeInTime) {
                currentGroup.add(curr)
            } else {
                result.add(GroupedCallLogItem(currentGroup.first(), currentGroup.size, currentGroup.toList()))
                currentGroup = mutableListOf(curr)
            }
        }
        result.add(GroupedCallLogItem(currentGroup.first(), currentGroup.size, currentGroup.toList()))
        return result
    }

    private fun buildT9Suggestions(
        digits: String,
        allContacts: List<ContactEntry>,
        allLogs: List<CallLogEntry>,
        callingCards: Map<String, String>,
    ): List<T9Suggestion> {
        val clean = digits.filter { it.isDigit() }
        if (clean.isEmpty()) {
            return allContacts.take(25).mapNotNull { contact ->
                val num = contact.numbers.firstOrNull() ?: return@mapNotNull null
                T9Suggestion(
                    id = "all_${contact.id}_${num.normalized}",
                    displayName = contact.name,
                    number = num.number,
                    formattedNumber = BangladeshTelecomHelper.formatPhoneNumber(num.number),
                    photoUri = contact.photoUri,
                    callingCardPath = callingCards[num.normalized],
                    isSavedContact = true,
                    matchedQuery = "",
                )
            }
        }

        val results = mutableListOf<T9Suggestion>()
        val seenNumbers = mutableSetOf<String>()

        for (contact in allContacts) {
            val matchedNumber = contact.numbers.firstOrNull {
                it.normalized.contains(clean) || it.number.filter { c -> c.isDigit() }.contains(clean)
            }
            val matchedName = contact.t9NameDigits.contains(clean)
            if (matchedNumber != null || matchedName) {
                val chosenNum = matchedNumber ?: contact.numbers.firstOrNull() ?: continue
                if (seenNumbers.add(chosenNum.normalized)) {
                    results.add(
                        T9Suggestion(
                            id = "c_${contact.id}_${chosenNum.normalized}",
                            displayName = contact.name,
                            number = chosenNum.number,
                            formattedNumber = BangladeshTelecomHelper.formatPhoneNumber(chosenNum.number),
                            photoUri = contact.photoUri,
                            callingCardPath = callingCards[chosenNum.normalized],
                            isSavedContact = true,
                            matchedQuery = clean,
                        )
                    )
                }
            }
            if (results.size >= 20) break
        }

        if (results.size < 20) {
            for (log in allLogs) {
                val normalized = BangladeshTelecomHelper.normalizeDigits(log.number)
                val rawDigits = log.number.filter { it.isDigit() }
                if ((normalized.contains(clean) || rawDigits.contains(clean)) && seenNumbers.add(normalized)) {
                    results.add(
                        T9Suggestion(
                            id = "l_${log.id}",
                            displayName = log.cachedName ?: log.formattedNumber,
                            number = log.number,
                            formattedNumber = log.formattedNumber,
                            photoUri = log.photoUri,
                            callingCardPath = callingCards[normalized],
                            isSavedContact = log.cachedName != null,
                            matchedQuery = clean,
                        )
                    )
                }
                if (results.size >= 20) break
            }
        }

        return results
    }

    private data class NavFilterState(
        val tab: DialerTab,
        val searchQuery: String,
        val recentsFilter: RecentsFilter,
        val favoritesExpanded: Boolean,
        val dialpadDigits: String,
    )

    private data class DataState(
        val contacts: List<ContactEntry>,
        val callLogs: List<CallLogEntry>,
        val simAccounts: List<SimAccountInfo>,
        val permissions: PermissionStatus,
        val isLoading: Boolean,
    )

    private data class OverlayState(
        val settings: DialerSettings,
        val pendingSimNumber: String?,
        val contactDetail: ContactEntry?,
        val logDetail: GroupedCallLogItem?,
        val recordings: List<CallRecordingItem>,
    )
}
