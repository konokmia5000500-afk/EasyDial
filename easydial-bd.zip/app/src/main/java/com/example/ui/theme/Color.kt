package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Google Dialer / Material 3 Cobalt & Slate Palette
val DialerBlue = Color(0xFF0B57D0)
val DialerBlueContainer = Color(0xFFD3E3FD)
val DialerOnBlueContainer = Color(0xFF041E49)

val DialerSkyLight = Color(0xFFA8C7FA)
val DialerSkyDarkContainer = Color(0xFF0842A0)

val DialerSurfaceLight = Color(0xFFF8FAFD)
val DialerSurfaceVariantLight = Color(0xFFE1E8F2)
val DialerCardLight = Color(0xFFFFFFFF)
val DialerOnSurfaceLight = Color(0xFF1A1C1E)
val DialerOnSurfaceVariantLight = Color(0xFF44474E)

val DialerSurfaceDark = Color(0xFF0F1419)
val DialerSurfaceVariantDark = Color(0xFF1E252D)
val DialerCardDark = Color(0xFF171D24)
val DialerOnSurfaceDark = Color(0xFFE3E8EF)
val DialerOnSurfaceVariantDark = Color(0xFFC4C7C5)

// Semantic Call Status Colors
val CallGreen = Color(0xFF146C2E)
val CallGreenBright = Color(0xFF1E8E3E)
val CallGreenContainer = Color(0xFFC4EED0)
val MissedRed = Color(0xFFB3261E)
val MissedRedDark = Color(0xFFF2B8B5)
val OutgoingBlue = Color(0xFF0B57D0)
val IncomingTeal = Color(0xFF006A6A)

// Avatar Palette (Vibrant M3 tones)
val AvatarPalette = listOf(
    Color(0xFF1A73E8),
    Color(0xFF1E8E3E),
    Color(0xFFE37400),
    Color(0xFF9334E6),
    Color(0xFFD93025),
    Color(0xFF00897B),
    Color(0xFF3949AB),
    Color(0xFFC2185B),
)
