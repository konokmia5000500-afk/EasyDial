package com.example.ui.screens

import android.text.format.DateUtils
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.CallMade
import androidx.compose.material.icons.automirrored.rounded.CallMissed
import androidx.compose.material.icons.automirrored.rounded.CallReceived
import androidx.compose.material.icons.automirrored.rounded.Message
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Voicemail
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.AppLanguage
import com.example.model.CallDirectionType
import com.example.model.ContactEntry
import com.example.model.GroupedCallLogItem
import com.example.model.PermissionStatus
import com.example.model.RecentsFilter
import com.example.ui.components.CarrierBadgeChip
import com.example.ui.components.ContactAvatar
import com.example.ui.components.DefaultDialerBanner
import com.example.ui.components.PermissionRequestBanner
import com.example.ui.theme.IncomingTeal
import com.example.ui.theme.MissedRed
import com.example.ui.theme.OutgoingBlue
import com.example.util.AppStrings
import com.example.util.BangladeshTelecomHelper
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    favorites: List<ContactEntry>,
    favoritesExpanded: Boolean,
    groupedCallLogs: List<GroupedCallLogItem>,
    matchedSearchContacts: List<ContactEntry>,
    searchQuery: String,
    selectedFilter: RecentsFilter,
    callerIdEnabled: Boolean,
    contactCallingCards: Map<String, String>,
    permissions: PermissionStatus,
    language: AppLanguage,
    strings: AppStrings,
    onToggleFavoritesExpanded: () -> Unit,
    onViewContacts: () -> Unit,
    onSelectFilter: (RecentsFilter) -> Unit,
    onCallNumber: (String) -> Unit,
    onOpenCallDetail: (GroupedCallLogItem) -> Unit,
    onOpenContactDetail: (ContactEntry) -> Unit,
    onRequestPermissions: () -> Unit,
    onSetDefaultDialer: () -> Unit,
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Horizontal Filter Chips Row (All, Missed, Contacts, Outgoing, Incoming)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val filters = listOf(
                RecentsFilter.ALL to strings.filterAll,
                RecentsFilter.MISSED to strings.filterMissed,
                RecentsFilter.CONTACTS to strings.filterContacts,
                RecentsFilter.OUTGOING to strings.filterOutgoing,
                RecentsFilter.INCOMING to strings.filterIncoming,
            )
            filters.forEach { (filter, label) ->
                FilterChip(
                    selected = selectedFilter == filter,
                    onClick = { onSelectFilter(filter) },
                    label = { Text(label) },
                    shape = RoundedCornerShape(12.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    ),
                    modifier = Modifier.testTag("home_filter_${filter.name.lowercase()}"),
                )
            }
        }

        if (!permissions.allCoreGranted) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                PermissionRequestBanner(
                    strings = strings,
                    onGrantPermissions = onRequestPermissions,
                )
            }
            return
        }

        val dateSections = remember(groupedCallLogs, strings) {
            groupSectionsByDate(groupedCallLogs, strings)
        }

        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            if (!permissions.isDefaultDialer) {
                item(key = "default_dialer_banner") {
                    DefaultDialerBanner(
                        strings = strings,
                        onSetDefault = onSetDefaultDialer,
                        modifier = Modifier.padding(vertical = 4.dp),
                    )
                }
            }

            // Collapsible Favorites Carousel + "View contacts" pill (matches Screenshot 5)
            if (searchQuery.isBlank()) {
                item(key = "favorites_header") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp, bottom = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable(onClick = onToggleFavoritesExpanded)
                                .padding(horizontal = 4.dp, vertical = 6.dp)
                                .testTag("favorites_collapse_toggle"),
                        ) {
                            Text(
                                text = strings.favoritesTitle,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Spacer(Modifier.width(4.dp))
                            Icon(
                                imageVector = if (favoritesExpanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp),
                            )
                        }

                        Surface(
                            onClick = onViewContacts,
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.surfaceContainerHigh,
                            modifier = Modifier.testTag("view_contacts_pill_button"),
                        ) {
                            Text(
                                text = strings.viewContacts,
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                            )
                        }
                    }
                }

                item(key = "favorites_carousel") {
                    AnimatedVisibility(visible = favoritesExpanded) {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            contentPadding = PaddingValues(vertical = 6.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            items(favorites, key = { "fav_${it.id}" }) { contact ->
                                val primaryNum = contact.numbers.firstOrNull()?.number.orEmpty()
                                val normalized = BangladeshTelecomHelper.normalizeDigits(primaryNum)
                                val cardPath = contactCallingCards[normalized]
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .width(68.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .clickable {
                                            if (primaryNum.isNotBlank()) onCallNumber(primaryNum)
                                        }
                                        .padding(vertical = 4.dp)
                                        .testTag("home_favorite_${contact.id}"),
                                ) {
                                    Box {
                                        ContactAvatar(
                                            name = contact.name,
                                            number = primaryNum,
                                            photoUri = contact.photoUri,
                                            callingCardPath = cardPath,
                                            size = 56.dp,
                                        )
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.surface,
                                            shadowElevation = 2.dp,
                                            modifier = Modifier
                                                .size(20.dp)
                                                .align(Alignment.BottomEnd),
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    imageVector = Icons.Rounded.Call,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.size(11.dp),
                                                )
                                            }
                                        }
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        text = contact.name,
                                        style = MaterialTheme.typography.labelMedium,
                                        textAlign = TextAlign.Center,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }

                            item(key = "add_favorite_shortcut") {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .width(68.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .clickable(onClick = onViewContacts)
                                        .padding(vertical = 4.dp)
                                        .testTag("home_add_favorite_button"),
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                                        modifier = Modifier.size(56.dp),
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Rounded.PersonAdd,
                                                contentDescription = strings.addShortcut,
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                        }
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        text = strings.addShortcut,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center,
                                    )
                                }
                            }
                        }
                    }
                }
            } else if (matchedSearchContacts.isNotEmpty()) {
                item(key = "search_contacts_header") {
                    Text(
                        text = strings.tabContacts,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 6.dp, start = 4.dp),
                    )
                }
                items(matchedSearchContacts.take(10), key = { "sc_${it.id}" }) { contact ->
                    val num = contact.numbers.firstOrNull()?.number.orEmpty()
                    val cardPath = contactCallingCards[BangladeshTelecomHelper.normalizeDigits(num)]
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLowest,
                        tonalElevation = 1.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .clickable { onOpenContactDetail(contact) },
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            ContactAvatar(
                                name = contact.name,
                                number = num,
                                photoUri = contact.photoUri,
                                callingCardPath = cardPath,
                                size = 44.dp,
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = contact.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    text = BangladeshTelecomHelper.formatPhoneNumber(num),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            IconButton(onClick = { if (num.isNotBlank()) onCallNumber(num) }) {
                                Icon(
                                    imageVector = Icons.Rounded.Call,
                                    contentDescription = strings.callAction,
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }
                    }
                }
            }

            if (dateSections.isEmpty() && matchedSearchContacts.isEmpty()) {
                item(key = "empty_recents") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 44.dp, start = 24.dp, end = 24.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(72.dp),
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Rounded.History,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(34.dp),
                                    )
                                }
                            }
                            Spacer(Modifier.height(16.dp))
                            Text(
                                text = strings.noRecentsTitle,
                                style = MaterialTheme.typography.titleLarge,
                                textAlign = TextAlign.Center,
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = strings.noRecentsDesc,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            } else {
                dateSections.forEach { (sectionHeader, groupItems) ->
                    item(key = "header_$sectionHeader") {
                        Text(
                            text = sectionHeader,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 8.dp, bottom = 2.dp, start = 4.dp),
                        )
                    }
                    items(groupItems, key = { it.primary.id }) { group ->
                        val normalized = BangladeshTelecomHelper.normalizeDigits(group.primary.number)
                        GroupedCallLogCard(
                            group = group,
                            callingCardPath = contactCallingCards[normalized],
                            callerIdEnabled = callerIdEnabled,
                            language = language,
                            strings = strings,
                            onCall = { onCallNumber(group.primary.number) },
                            onClick = { onOpenCallDetail(group) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupedCallLogCard(
    group: GroupedCallLogItem,
    callingCardPath: String?,
    callerIdEnabled: Boolean,
    language: AppLanguage,
    strings: AppStrings,
    onCall: () -> Unit,
    onClick: () -> Unit,
) {
    val entry = group.primary
    val isMissed = entry.type == CallDirectionType.MISSED || entry.type == CallDirectionType.REJECTED
    val directionIcon: ImageVector
    val directionTint: Color
    when (entry.type) {
        CallDirectionType.INCOMING -> {
            directionIcon = Icons.AutoMirrored.Rounded.CallReceived
            directionTint = IncomingTeal
        }
        CallDirectionType.OUTGOING -> {
            directionIcon = Icons.AutoMirrored.Rounded.CallMade
            directionTint = OutgoingBlue
        }
        CallDirectionType.MISSED, CallDirectionType.REJECTED -> {
            directionIcon = Icons.AutoMirrored.Rounded.CallMissed
            directionTint = MissedRed
        }
        CallDirectionType.BLOCKED -> {
            directionIcon = Icons.Rounded.Block
            directionTint = MissedRed
        }
        CallDirectionType.VOICEMAIL -> {
            directionIcon = Icons.Rounded.Voicemail
            directionTint = OutgoingBlue
        }
    }

    val baseTitle = entry.cachedName ?: entry.formattedNumber.ifBlank { strings.unknownCaller }
    val titleWithCount = if (group.count > 1) "$baseTitle (${group.count})" else baseTitle
    val timeText = remember(entry.dateMillis) { formatCallTimestamp(entry.dateMillis) }

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        tonalElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag("call_log_item_${entry.id}"),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ContactAvatar(
                name = entry.cachedName,
                number = entry.number,
                photoUri = entry.photoUri,
                callingCardPath = callingCardPath,
                size = 46.dp,
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = titleWithCount,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = if (isMissed) FontWeight.SemiBold else FontWeight.Medium,
                    color = if (isMissed) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = directionIcon,
                        contentDescription = null,
                        tint = directionTint,
                        modifier = Modifier.size(15.dp),
                    )
                    Spacer(Modifier.width(5.dp))
                    val subInfo = buildString {
                        if (entry.cachedName == null) {
                            append("Mobile")
                        } else {
                            append(entry.formattedNumber)
                        }
                        append(" • ")
                        append(timeText)
                        if (entry.durationSeconds > 0 && !isMissed) {
                            append(" • ")
                            append(formatDurationShort(entry.durationSeconds))
                        }
                    }
                    Text(
                        text = subInfo,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isMissed) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (callerIdEnabled && entry.carrier != null) {
                    Spacer(Modifier.height(2.dp))
                    val carrierLabel = if (language == AppLanguage.BANGLA) {
                        entry.carrier.nameBn
                    } else {
                        entry.carrier.nameEn
                    }
                    Text(
                        text = entry.simSlotLabel?.let { "$carrierLabel • $it" } ?: carrierLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color(entry.carrier.colorHex),
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                } else if (entry.simSlotLabel != null) {
                    Text(
                        text = entry.simSlotLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            IconButton(
                onClick = onCall,
                modifier = Modifier.testTag("call_back_button_${entry.id}"),
            ) {
                Icon(
                    imageVector = Icons.Rounded.Call,
                    contentDescription = strings.callAction,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallLogDetailBottomSheet(
    group: GroupedCallLogItem,
    callingCardPath: String?,
    language: AppLanguage,
    strings: AppStrings,
    onCall: (String) -> Unit,
    onMessage: (String) -> Unit,
    onAddToContacts: (String) -> Unit,
    onBlockNumber: (String) -> Unit,
    onDeleteGroup: (GroupedCallLogItem) -> Unit,
    onDismiss: () -> Unit,
) {
    val entry = group.primary
    val clipboard = LocalClipboardManager.current
    val fullDate = remember(entry.dateMillis) {
        SimpleDateFormat("EEE, dd MMM yyyy • hh:mm a", Locale.getDefault()).format(Date(entry.dateMillis))
    }
    val typeLabel = when (entry.type) {
        CallDirectionType.INCOMING -> strings.incomingCall
        CallDirectionType.OUTGOING -> strings.outgoingCall
        CallDirectionType.MISSED -> strings.missedCall
        CallDirectionType.REJECTED -> strings.rejectedCall
        CallDirectionType.BLOCKED -> strings.blockedCall
        CallDirectionType.VOICEMAIL -> strings.voicemailCall
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ContactAvatar(
                    name = entry.cachedName,
                    number = entry.number,
                    photoUri = entry.photoUri,
                    callingCardPath = callingCardPath,
                    size = 56.dp,
                )
                Spacer(Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = entry.cachedName ?: entry.formattedNumber.ifBlank { strings.unknownCaller },
                        style = MaterialTheme.typography.titleLarge,
                    )
                    Text(
                        text = entry.formattedNumber,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = if (group.count > 1) "$typeLabel (${group.count}) • $fullDate" else "$typeLabel • $fullDate",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (entry.durationSeconds > 0) {
                        Text(
                            text = formatDurationShort(entry.durationSeconds),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            entry.carrier?.let {
                CarrierBadgeChip(carrier = it, language = language)
                Spacer(Modifier.height(10.dp))
            }
            HorizontalDivider()
            Spacer(Modifier.height(8.dp))

            SheetActionItem(
                icon = Icons.Rounded.Call,
                label = "${strings.callAction} ${entry.formattedNumber}",
                onClick = {
                    onDismiss()
                    onCall(entry.number)
                },
            )
            SheetActionItem(
                icon = Icons.AutoMirrored.Rounded.Message,
                label = strings.messageAction,
                onClick = {
                    onDismiss()
                    onMessage(entry.number)
                },
            )
            if (entry.cachedName == null) {
                SheetActionItem(
                    icon = Icons.Rounded.PersonAdd,
                    label = strings.addToContacts,
                    onClick = {
                        onDismiss()
                        onAddToContacts(entry.number)
                    },
                )
            }
            SheetActionItem(
                icon = Icons.Rounded.ContentCopy,
                label = strings.copyNumber,
                onClick = {
                    clipboard.setText(AnnotatedString(entry.number))
                    onDismiss()
                },
            )
            SheetActionItem(
                icon = Icons.Rounded.Block,
                label = strings.blockNumber,
                tint = MaterialTheme.colorScheme.error,
                onClick = { onBlockNumber(entry.number) },
            )
            SheetActionItem(
                icon = Icons.Rounded.DeleteOutline,
                label = strings.deleteLog,
                tint = MaterialTheme.colorScheme.error,
                onClick = { onDeleteGroup(group) },
            )
            Spacer(Modifier.height(18.dp))
        }
    }
}

@Composable
private fun SheetActionItem(
    icon: ImageVector,
    label: String,
    tint: Color = MaterialTheme.colorScheme.onSurface,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = tint)
        Spacer(Modifier.width(16.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = tint,
        )
    }
}

private fun groupSectionsByDate(
    groups: List<GroupedCallLogItem>,
    strings: AppStrings,
): List<Pair<String, List<GroupedCallLogItem>>> {
    val todayCal = Calendar.getInstance()
    val yesterdayCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    val itemCal = Calendar.getInstance()

    val grouped = linkedMapOf<String, MutableList<GroupedCallLogItem>>()
    for (item in groups) {
        itemCal.timeInMillis = item.primary.dateMillis
        val key = when {
            isSameDay(itemCal, todayCal) -> strings.today
            isSameDay(itemCal, yesterdayCal) -> strings.yesterday
            else -> strings.earlier
        }
        grouped.getOrPut(key) { mutableListOf() }.add(item)
    }
    return grouped.entries.map { it.key to it.value }
}

private fun isSameDay(a: Calendar, b: Calendar): Boolean =
    a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
        a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)

private fun formatCallTimestamp(millis: Long): String {
    val now = System.currentTimeMillis()
    return if (now - millis < DateUtils.DAY_IN_MILLIS) {
        SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(millis))
    } else {
        SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(millis))
    }
}

private fun formatDurationShort(seconds: Long): String {
    val mins = seconds / 60
    val secs = seconds % 60
    return if (mins > 0) "${mins}m ${secs}s" else "${secs}s"
}
