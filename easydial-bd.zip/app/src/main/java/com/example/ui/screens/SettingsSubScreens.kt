package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.FlipCameraAndroid
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PhoneEnabled
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.SimCard
import androidx.compose.material.icons.rounded.SortByAlpha
import androidx.compose.material.icons.rounded.Swipe
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.AppLanguage
import com.example.model.CallerIdAnnouncementMode
import com.example.model.DialerSettings
import com.example.model.IncomingCallGesture
import com.example.model.SimAccountInfo
import com.example.model.SimPreference
import com.example.model.ThemeMode
import com.example.ui.components.consumeBackgroundTouches
import com.example.util.AppStrings

@Composable
fun CallerIdSpamScreen(
    enabled: Boolean,
    strings: AppStrings,
    onBack: () -> Unit,
    onToggleEnabled: (Boolean) -> Unit,
) {
    SubSettingScaffold(title = strings.settingsCallerIdSpam, onBack = onBack) {
        item {
            SubSettingSwitchCard(
                icon = Icons.Rounded.Shield,
                title = strings.settingsCallerIdSpam,
                subtitle = strings.settingsCallerIdSpamDesc,
                checked = enabled,
                onCheckedChange = onToggleEnabled,
                testTag = "caller_id_spam_switch",
            )
        }
    }
}

@Composable
fun CallingAccountsScreen(
    simPreference: SimPreference,
    simAccounts: List<SimAccountInfo>,
    strings: AppStrings,
    onBack: () -> Unit,
    onSimPreferenceChange: (SimPreference) -> Unit,
    onOpenSystemCallingAccounts: () -> Unit,
) {
    val sim1Label = simAccounts.getOrNull(0)?.let { "${it.displayName} • ${it.carrierName}" }
        ?: strings.simAlways1
    val sim2Label = simAccounts.getOrNull(1)?.let { "${it.displayName} • ${it.carrierName}" }
        ?: strings.simAlways2

    SubSettingScaffold(title = strings.settingsCallingAccounts, onBack = onBack) {
        item {
            Text(
                text = strings.settingsSimPreference,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 6.dp, top = 4.dp),
            )
        }
        item {
            val options = listOf(
                SimPreference.ASK_EVERY_TIME to strings.simAskEveryTime,
                SimPreference.SIM_1 to sim1Label,
                SimPreference.SIM_2 to sim2Label,
            )
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                    options.forEach { (pref, label) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSimPreferenceChange(pref) }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                                .testTag("sim_pref_${pref.name.lowercase()}"),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.SimCard,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = label,
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.weight(1f),
                            )
                            RadioButton(
                                selected = simPreference == pref,
                                onClick = { onSimPreferenceChange(pref) },
                            )
                        }
                    }
                }
            }
        }
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .clickable(onClick = onOpenSystemCallingAccounts)
                    .testTag("open_system_calling_accounts_row"),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PhoneEnabled,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                    Spacer(Modifier.width(14.dp))
                    Text(
                        text = strings.openSystemCallingAccounts,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f),
                    )
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
fun DisplayOptionsScreen(
    settings: DialerSettings,
    strings: AppStrings,
    onBack: () -> Unit,
    onLanguageChange: (AppLanguage) -> Unit,
    onThemeModeChange: (ThemeMode) -> Unit,
    onSortByLastNameChange: (Boolean) -> Unit,
) {
    SubSettingScaffold(title = strings.settingsDisplayOptions, onBack = onBack) {
        item {
            Text(
                text = strings.settingsLanguage,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 6.dp, top = 4.dp),
            )
        }
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                    AppLanguage.entries.forEach { lang ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onLanguageChange(lang) }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                                .testTag("display_lang_${lang.code}"),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Language,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = lang.displayName,
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.weight(1f),
                            )
                            RadioButton(
                                selected = settings.language == lang,
                                onClick = { onLanguageChange(lang) },
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = strings.settingsTheme,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 6.dp, top = 6.dp),
            )
        }
        item {
            val themes = listOf(
                ThemeMode.SYSTEM to strings.themeSystem,
                ThemeMode.LIGHT to strings.themeLight,
                ThemeMode.DARK to strings.themeDark,
            )
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                    themes.forEach { (mode, label) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onThemeModeChange(mode) }
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                                .testTag("display_theme_${mode.name.lowercase()}"),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Palette,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = label,
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.weight(1f),
                            )
                            RadioButton(
                                selected = settings.themeMode == mode,
                                onClick = { onThemeModeChange(mode) },
                            )
                        }
                    }
                }
            }
        }

        item {
            SubSettingSwitchCard(
                icon = Icons.Rounded.SortByAlpha,
                title = strings.sortByLastName,
                subtitle = null,
                checked = settings.sortByLastName,
                onCheckedChange = onSortByLastNameChange,
                testTag = "display_sort_last_name_switch",
            )
        }
    }
}

@Composable
fun IncomingCallGestureScreen(
    selectedGesture: IncomingCallGesture,
    strings: AppStrings,
    onBack: () -> Unit,
    onSelectGesture: (IncomingCallGesture) -> Unit,
) {
    SubSettingScaffold(title = strings.settingsIncomingCallGesture, onBack = onBack) {
        item {
            SubSettingRadioCard(
                icon = Icons.Rounded.Swipe,
                title = strings.gestureSwipeTitle,
                description = strings.gestureSwipeDesc,
                selected = selectedGesture == IncomingCallGesture.SWIPE,
                onClick = { onSelectGesture(IncomingCallGesture.SWIPE) },
                testTag = "gesture_swipe_option",
            )
        }
        item {
            SubSettingRadioCard(
                icon = Icons.Rounded.TouchApp,
                title = strings.gestureSingleTapTitle,
                description = strings.gestureSingleTapDesc,
                selected = selectedGesture == IncomingCallGesture.SINGLE_TAP,
                onClick = { onSelectGesture(IncomingCallGesture.SINGLE_TAP) },
                testTag = "gesture_single_tap_option",
            )
        }
    }
}

@Composable
fun SoundsVibrationScreen(
    settings: DialerSettings,
    strings: AppStrings,
    onBack: () -> Unit,
    onDialpadTonesChange: (Boolean) -> Unit,
    onDialpadVibrateChange: (Boolean) -> Unit,
    onVibrateOnConnectChange: (Boolean) -> Unit,
) {
    SubSettingScaffold(title = strings.settingsSoundsVibration, onBack = onBack) {
        item {
            SubSettingSwitchCard(
                icon = Icons.AutoMirrored.Rounded.VolumeUp,
                title = strings.dialpadTones,
                subtitle = null,
                checked = settings.dialpadTones,
                onCheckedChange = onDialpadTonesChange,
                testTag = "setting_dialpad_tones_switch",
            )
        }
        item {
            SubSettingSwitchCard(
                icon = Icons.Rounded.Vibration,
                title = strings.dialpadVibrate,
                subtitle = null,
                checked = settings.dialpadVibrate,
                onCheckedChange = onDialpadVibrateChange,
                testTag = "setting_dialpad_vibrate_switch",
            )
        }
        item {
            SubSettingSwitchCard(
                icon = Icons.Rounded.Vibration,
                title = strings.vibrateOnConnect,
                subtitle = null,
                checked = settings.vibrateOnConnect,
                onCheckedChange = onVibrateOnConnectChange,
                testTag = "setting_vibrate_on_connect_switch",
            )
        }
    }
}

@Composable
fun CallerIdAnnouncementScreen(
    mode: CallerIdAnnouncementMode,
    strings: AppStrings,
    onBack: () -> Unit,
    onSelectMode: (CallerIdAnnouncementMode) -> Unit,
) {
    SubSettingScaffold(title = strings.settingsCallerIdAnnouncement, onBack = onBack) {
        item {
            SubSettingRadioCard(
                icon = Icons.Rounded.Campaign,
                title = strings.announceCallerNever,
                description = "",
                selected = mode == CallerIdAnnouncementMode.NEVER,
                onClick = { onSelectMode(CallerIdAnnouncementMode.NEVER) },
                testTag = "caller_id_announce_never",
            )
        }
        item {
            SubSettingRadioCard(
                icon = Icons.Rounded.Campaign,
                title = strings.announceCallerAlways,
                description = "",
                selected = mode == CallerIdAnnouncementMode.ALWAYS,
                onClick = { onSelectMode(CallerIdAnnouncementMode.ALWAYS) },
                testTag = "caller_id_announce_always",
            )
        }
    }
}

@Composable
fun FlipToSilenceScreen(
    enabled: Boolean,
    strings: AppStrings,
    onBack: () -> Unit,
    onToggleEnabled: (Boolean) -> Unit,
) {
    SubSettingScaffold(title = strings.settingsFlipToSilence, onBack = onBack) {
        item {
            SubSettingSwitchCard(
                icon = Icons.Rounded.FlipCameraAndroid,
                title = strings.settingsFlipToSilence,
                subtitle = strings.flipToSilenceDesc,
                checked = enabled,
                onCheckedChange = onToggleEnabled,
                testTag = "flip_to_silence_switch",
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SubSettingScaffold(
    title: String,
    onBack: () -> Unit,
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit,
) {
    BackHandler(onBack = onBack)

    Surface(
        color = MaterialTheme.colorScheme.background,
        modifier = Modifier
            .fillMaxSize()
            .consumeBackgroundTouches(),
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(title) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                            )
                        }
                    },
                )
            },
        ) { innerPadding ->
            LazyColumn(
                contentPadding = PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    top = innerPadding.calculateTopPadding() + 8.dp,
                    bottom = innerPadding.calculateBottomPadding() + 24.dp,
                ),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize(),
                content = content,
            )
        }
    }
}

@Composable
private fun SubSettingSwitchCard(
    icon: ImageVector,
    title: String,
    subtitle: String?,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String,
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable { onCheckedChange(!checked) }
            .testTag(testTag),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium,
                )
                if (!subtitle.isNullOrBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
            )
        }
    }
}

@Composable
private fun SubSettingRadioCard(
    icon: ImageVector,
    title: String,
    description: String,
    selected: Boolean,
    testTag: String,
    onClick: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (selected) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f)
        } else {
            MaterialTheme.colorScheme.surfaceContainerLow
        },
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                if (description.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            RadioButton(
                selected = selected,
                onClick = onClick,
            )
        }
    }
}
