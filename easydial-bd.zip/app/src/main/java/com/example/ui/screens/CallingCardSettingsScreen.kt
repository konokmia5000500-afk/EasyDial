package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.model.ContactEntry
import com.example.model.DialerSettings
import com.example.ui.components.ContactAvatar
import com.example.ui.components.consumeBackgroundTouches
import com.example.util.AppStrings
import com.example.util.BangladeshTelecomHelper
import java.io.File

private val cardStyleGradients = listOf(
    listOf(Color(0xFF0A192F), Color(0xFF0F2544), Color(0xFF09121F)),
    listOf(Color(0xFF0D2E25), Color(0xFF145242), Color(0xFF081C17)),
    listOf(Color(0xFF28123B), Color(0xFF471E66), Color(0xFF160922)),
    listOf(Color(0xFF3A1219), Color(0xFF6B212D), Color(0xFF1D080C)),
)

fun callingCardGradientColors(styleIndex: Int): List<Color> =
    cardStyleGradients.getOrElse(styleIndex) { cardStyleGradients.first() }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallingCardSettingsScreen(
    settings: DialerSettings,
    contacts: List<ContactEntry>,
    strings: AppStrings,
    onBack: () -> Unit,
    onSelectDefaultStyle: (Int) -> Unit,
    onPickDefaultPhoto: (Uri) -> Unit,
    onClearDefaultPhoto: () -> Unit,
    onPickContactPhoto: (String, Uri) -> Unit,
    onRemoveContactPhoto: (String) -> Unit,
) {
    BackHandler(onBack = onBack)

    var pendingContactNumber by remember { mutableStateOf<String?>(null) }

    val defaultPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
    ) { uri ->
        if (uri != null) onPickDefaultPhoto(uri)
    }

    val contactPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
    ) { uri ->
        val num = pendingContactNumber
        pendingContactNumber = null
        if (uri != null && !num.isNullOrBlank()) {
            onPickContactPhoto(num, uri)
        }
    }

    Surface(
        color = MaterialTheme.colorScheme.background,
        modifier = Modifier
            .fillMaxSize()
            .consumeBackgroundTouches(),
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(strings.settingsCallingCard) },
                    navigationIcon = {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("calling_card_back"),
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                            )
                        }
                    },
                )
            },
        ) { innerPadding ->
            LazyColumn(
                contentPadding = PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    top = innerPadding.calculateTopPadding() + 8.dp,
                    bottom = innerPadding.calculateBottomPadding() + 24.dp,
                ),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                item {
                    Text(
                        text = strings.callingCardDesc,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }

                // Live Preview of Default Calling Card
                item {
                    val customBgFile = settings.defaultCallingCardPath?.let(::File)?.takeIf { it.exists() }
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(210.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        callingCardGradientColors(settings.defaultCallingCardStyle)
                                    )
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (customBgFile != null) {
                                AsyncImage(
                                    model = ImageRequest.Builder(LocalContext.current)
                                        .data(customBgFile)
                                        .crossfade(true)
                                        .build(),
                                    contentDescription = strings.defaultCallingCardTitle,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize(),
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.42f))
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                ContactAvatar(
                                    name = "Alaap Caller",
                                    number = "01700000000",
                                    callingCardPath = settings.defaultCallingCardPath,
                                    size = 70.dp,
                                )
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    text = "Alaap Caller",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                )
                                Text(
                                    text = strings.ringingStatus,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White.copy(alpha = 0.85f),
                                )
                            }
                        }
                    }
                }

                // Default Background Actions & Color Presets
                item {
                    Text(
                        text = strings.defaultCallingCardTitle,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(start = 6.dp, top = 4.dp),
                    )
                }

                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                cardStyleGradients.forEachIndexed { idx, gradient ->
                                    val isSelected = settings.defaultCallingCardPath == null &&
                                        settings.defaultCallingCardStyle == idx
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(CircleShape)
                                            .background(Brush.linearGradient(gradient))
                                            .then(
                                                if (isSelected) {
                                                    Modifier.border(2.5.dp, MaterialTheme.colorScheme.primary, CircleShape)
                                                } else {
                                                    Modifier
                                                }
                                            )
                                            .clickable {
                                                onClearDefaultPhoto()
                                                onSelectDefaultStyle(idx)
                                            }
                                            .testTag("calling_card_preset_$idx"),
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        if (isSelected) {
                                            Icon(
                                                imageVector = Icons.Rounded.Check,
                                                contentDescription = null,
                                                tint = Color.White,
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(Modifier.height(14.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = {
                                        defaultPhotoPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    modifier = Modifier.testTag("pick_default_card_photo_button"),
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.AddPhotoAlternate,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(strings.chooseCardPhoto)
                                }

                                if (settings.defaultCallingCardPath != null) {
                                    OutlinedButton(onClick = onClearDefaultPhoto) {
                                        Text(strings.removeCardPhoto)
                                    }
                                }
                            }
                        }
                    }
                }

                // Contact Calling Cards Section
                item {
                    Text(
                        text = strings.contactCallingCardsTitle,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(start = 6.dp, top = 6.dp),
                    )
                }

                if (contacts.isEmpty()) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                text = strings.noContactsDesc,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(16.dp),
                            )
                        }
                    }
                } else {
                    items(contacts.take(40), key = { "cc_${it.id}" }) { contact ->
                        val primaryNum = contact.numbers.firstOrNull()?.number.orEmpty()
                        val normalized = BangladeshTelecomHelper.normalizeDigits(primaryNum)
                        val customCard = settings.contactCallingCards[normalized]
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .clickable(enabled = primaryNum.isNotBlank()) {
                                    pendingContactNumber = primaryNum
                                    contactPhotoPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                ContactAvatar(
                                    name = contact.name,
                                    number = primaryNum,
                                    photoUri = contact.photoUri,
                                    callingCardPath = customCard,
                                    size = 44.dp,
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = contact.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        text = BangladeshTelecomHelper.formatPhoneNumber(primaryNum),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                if (customCard != null) {
                                    IconButton(onClick = { onRemoveContactPhoto(primaryNum) }) {
                                        Icon(
                                            imageVector = Icons.Rounded.DeleteOutline,
                                            contentDescription = strings.removeCardPhoto,
                                            tint = MaterialTheme.colorScheme.error,
                                        )
                                    }
                                } else {
                                    IconButton(
                                        enabled = primaryNum.isNotBlank(),
                                        onClick = {
                                            pendingContactNumber = primaryNum
                                            contactPhotoPicker.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Image,
                                            contentDescription = strings.chooseCardPhoto,
                                            tint = MaterialTheme.colorScheme.primary,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
