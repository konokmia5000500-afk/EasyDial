package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Message
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.BluetoothAudio
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CallEnd
import androidx.compose.material.icons.rounded.Dialpad
import androidx.compose.material.icons.rounded.FiberManualRecord
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.model.AppLanguage
import com.example.model.IncomingCallGesture
import com.example.model.RecordingAnnouncementMode
import com.example.telecom.ActiveCallStatus
import com.example.telecom.ActiveCallUiState
import com.example.telecom.RecordingPhase
import com.example.telecom.RecordingUiState
import com.example.ui.theme.CallGreenBright
import com.example.ui.theme.MissedRed
import com.example.util.AppStrings
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InCallScreen(
    callState: ActiveCallUiState,
    recordingState: RecordingUiState,
    callRecordingEnabled: Boolean,
    announcementMode: RecordingAnnouncementMode,
    incomingCallGesture: IncomingCallGesture,
    photoUri: String?,
    callingCardPath: String?,
    callingCardStyle: Int,
    strings: AppStrings,
    language: AppLanguage,
    quickResponses: List<String>,
    onAnswer: () -> Unit,
    onDecline: (String?) -> Unit,
    onEndCall: () -> Unit,
    onToggleMute: () -> Unit,
    onToggleSpeaker: () -> Unit,
    onToggleBluetooth: () -> Unit,
    onToggleHold: () -> Unit,
    onPlayDtmf: (Char) -> Unit,
    onToggleRecording: () -> Unit,
    onToggleAnnouncementMode: (RecordingAnnouncementMode) -> Unit,
) {
    var showKeypad by remember { mutableStateOf(false) }
    var showQuickSmsSheet by remember { mutableStateOf(false) }
    var dtmfBuffer by remember { mutableStateOf("") }
    var elapsedSeconds by remember { mutableLongStateOf(0L) }
    var recElapsedSeconds by remember { mutableLongStateOf(0L) }

    LaunchedEffect(callState.status, callState.connectedAtMillis) {
        val connectedAt = callState.connectedAtMillis
        if (callState.status == ActiveCallStatus.ACTIVE && connectedAt != null) {
            while (true) {
                elapsedSeconds = ((System.currentTimeMillis() - connectedAt) / 1000L).coerceAtLeast(0L)
                delay(1000L)
            }
        }
    }

    LaunchedEffect(recordingState.phase, recordingState.startedAtMillis) {
        val startedAt = recordingState.startedAtMillis
        if (recordingState.phase == RecordingPhase.RECORDING && startedAt != null) {
            while (true) {
                recElapsedSeconds = ((System.currentTimeMillis() - startedAt) / 1000L).coerceAtLeast(0L)
                delay(1000L)
            }
        } else {
            recElapsedSeconds = 0L
        }
    }

    val statusText = when (callState.status) {
        ActiveCallStatus.DIALING -> strings.callingStatus
        ActiveCallStatus.RINGING -> strings.ringingStatus
        ActiveCallStatus.HOLDING -> strings.onHoldStatus
        ActiveCallStatus.DISCONNECTING, ActiveCallStatus.DISCONNECTED -> strings.endedStatus
        ActiveCallStatus.ACTIVE -> "%02d:%02d".format(elapsedSeconds / 60, elapsedSeconds % 60)
    }

    val pulseTransition = rememberInfiniteTransition(label = "call_pulse")
    val pulseScale by pulseTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulse_scale",
    )

    val isRecordingOrAnnouncing = recordingState.phase != RecordingPhase.IDLE
    val cardFile = remember(callingCardPath) {
        callingCardPath?.let(::File)?.takeIf { it.exists() }
    }
    val gradientColors = remember(callingCardStyle) {
        callingCardGradientColors(callingCardStyle)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(colors = gradientColors)),
    ) {
        if (cardFile != null) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(cardFile)
                    .crossfade(true)
                    .build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = 0.56f),
                                Color.Black.copy(alpha = 0.42f),
                                Color.Black.copy(alpha = 0.72f),
                            )
                        )
                    )
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            // Top caller metadata + live recording pill
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 18.dp),
            ) {
                if (isRecordingOrAnnouncing) {
                    Surface(
                        color = Color(0xFFD93025).copy(alpha = 0.92f),
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.padding(bottom = 12.dp),
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.FiberManualRecord,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(12.dp),
                            )
                            Spacer(Modifier.width(6.dp))
                            val recText = if (recordingState.phase == RecordingPhase.ANNOUNCING) {
                                strings.announcingRecordingStatus
                            } else {
                                "${strings.recordingActiveBadge} • %02d:%02d".format(
                                    recElapsedSeconds / 60,
                                    recElapsedSeconds % 60,
                                )
                            }
                            Text(
                                text = recText,
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }
                }

                callState.carrier?.let { carrier ->
                    Surface(
                        color = Color(carrier.colorHex).copy(alpha = 0.28f),
                        shape = RoundedCornerShape(50),
                    ) {
                        Text(
                            text = if (language == AppLanguage.BANGLA) carrier.nameBn else carrier.nameEn,
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp),
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                }

                Box(contentAlignment = Alignment.Center) {
                    if (callState.status == ActiveCallStatus.RINGING || callState.status == ActiveCallStatus.DIALING) {
                        Box(
                            modifier = Modifier
                                .size(120.dp)
                                .scale(pulseScale)
                                .clip(CircleShape)
                                .background(Color(0xFFA8C7FA).copy(alpha = 0.18f))
                        )
                    }
                    val avatarModel: Any? = when {
                        !photoUri.isNullOrBlank() -> photoUri
                        cardFile != null -> cardFile
                        else -> null
                    }
                    Box(
                        modifier = Modifier
                            .size(98.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1F3B64)),
                        contentAlignment = Alignment.Center,
                    ) {
                        val initial = (callState.callerName ?: callState.phoneNumber)
                            .firstOrNull { it.isLetter() }?.uppercaseChar()?.toString()
                        if (initial != null) {
                            Text(
                                text = initial,
                                color = Color.White,
                                fontSize = 38.sp,
                                fontWeight = FontWeight.SemiBold,
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.Person,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(46.dp),
                            )
                        }
                        if (avatarModel != null) {
                            AsyncImage(
                                model = ImageRequest.Builder(LocalContext.current)
                                    .data(avatarModel)
                                    .crossfade(true)
                                    .build(),
                                contentDescription = callState.callerName ?: callState.formattedNumber,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize(),
                            )
                        }
                    }
                }

                Spacer(Modifier.height(18.dp))

                Text(
                    text = callState.callerName ?: callState.formattedNumber.ifBlank { strings.unknownCaller },
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )

                if (callState.callerName != null && callState.formattedNumber.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = callState.formattedNumber,
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color(0xFFD6E2F5),
                    )
                }

                Spacer(Modifier.height(8.dp))

                Text(
                    text = statusText,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (callState.status == ActiveCallStatus.ACTIVE) Color(0xFF7FD99A) else Color(0xFFA8C7FA),
                    modifier = Modifier.testTag("in_call_status_text"),
                )

                recordingState.errorMessage?.let { err ->
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = err,
                        color = Color(0xFFF2B8B5),
                        style = MaterialTheme.typography.labelMedium,
                        textAlign = TextAlign.Center,
                    )
                }
            }

            // Middle: In-Call DTMF Keypad OR Call Control Grid
            if (callState.status != ActiveCallStatus.RINGING) {
                AnimatedVisibility(visible = showKeypad) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        if (dtmfBuffer.isNotEmpty()) {
                            Text(
                                text = dtmfBuffer,
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(bottom = 12.dp),
                            )
                        }
                        val rows = listOf(
                            listOf('1', '2', '3'),
                            listOf('4', '5', '6'),
                            listOf('7', '8', '9'),
                            listOf('*', '0', '#'),
                        )
                        rows.forEach { row ->
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(20.dp),
                                modifier = Modifier.padding(vertical = 6.dp),
                            ) {
                                row.forEach { ch ->
                                    Surface(
                                        onClick = {
                                            dtmfBuffer += ch
                                            onPlayDtmf(ch)
                                        },
                                        shape = CircleShape,
                                        color = Color.White.copy(alpha = 0.14f),
                                        modifier = Modifier.size(64.dp),
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = ch.toString(),
                                                fontSize = 24.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = Color.White,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        TextButton(onClick = { showKeypad = false }) {
                            Text(strings.hideKeypad, color = Color(0xFFA8C7FA))
                        }
                    }
                }

                AnimatedVisibility(visible = !showKeypad) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        if (callRecordingEnabled && recordingState.phase == RecordingPhase.IDLE) {
                            val isAnnounced = announcementMode == RecordingAnnouncementMode.ANNOUNCE_BOTH_SIDES
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = Color.White.copy(alpha = 0.13f),
                                modifier = Modifier
                                    .padding(bottom = 12.dp)
                                    .clip(RoundedCornerShape(50))
                                    .clickable {
                                        val next = if (isAnnounced) {
                                            RecordingAnnouncementMode.SILENT_NO_ANNOUNCEMENT
                                        } else {
                                            RecordingAnnouncementMode.ANNOUNCE_BOTH_SIDES
                                        }
                                        onToggleAnnouncementMode(next)
                                    }
                                    .testTag("incall_announcement_mode_chip"),
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                                ) {
                                    Icon(
                                        imageVector = if (isAnnounced) {
                                            Icons.Rounded.RecordVoiceOver
                                        } else {
                                            Icons.AutoMirrored.Rounded.VolumeOff
                                        },
                                        contentDescription = null,
                                        tint = Color(0xFFA8C7FA),
                                        modifier = Modifier.size(16.dp),
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = if (isAnnounced) {
                                            strings.announceBothSidesTitle
                                        } else {
                                            strings.silentRecordTitle
                                        },
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelMedium,
                                    )
                                }
                            }
                        }

                        Surface(
                            color = Color.White.copy(alpha = 0.10f),
                            shape = RoundedCornerShape(28.dp),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 18.dp, horizontal = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly,
                                ) {
                                    InCallActionTile(
                                        icon = if (callState.isMuted) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                                        label = strings.mute,
                                        isActive = callState.isMuted,
                                        onClick = onToggleMute,
                                        testTag = "incall_mute_button",
                                    )
                                    InCallActionTile(
                                        icon = Icons.Rounded.Dialpad,
                                        label = strings.keypad,
                                        isActive = showKeypad,
                                        onClick = { showKeypad = true },
                                        testTag = "incall_keypad_button",
                                    )
                                    InCallActionTile(
                                        icon = Icons.AutoMirrored.Rounded.VolumeUp,
                                        label = strings.speaker,
                                        isActive = callState.isSpeakerOn,
                                        onClick = onToggleSpeaker,
                                        testTag = "incall_speaker_button",
                                    )
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly,
                                ) {
                                    if (callRecordingEnabled) {
                                        InCallActionTile(
                                            icon = if (isRecordingOrAnnouncing) {
                                                Icons.Rounded.Stop
                                            } else {
                                                Icons.Rounded.FiberManualRecord
                                            },
                                            label = if (isRecordingOrAnnouncing) {
                                                strings.stopRecordButton
                                            } else {
                                                strings.recordButton
                                            },
                                            isActive = isRecordingOrAnnouncing,
                                            activeTint = Color(0xFFD93025),
                                            onClick = onToggleRecording,
                                            testTag = "incall_record_button",
                                        )
                                    }
                                    InCallActionTile(
                                        icon = if (callState.status == ActiveCallStatus.HOLDING) {
                                            Icons.Rounded.PlayArrow
                                        } else {
                                            Icons.Rounded.Pause
                                        },
                                        label = if (callState.status == ActiveCallStatus.HOLDING) {
                                            strings.resume
                                        } else {
                                            strings.hold
                                        },
                                        isActive = callState.status == ActiveCallStatus.HOLDING,
                                        onClick = onToggleHold,
                                        testTag = "incall_hold_button",
                                    )
                                    if (callState.isBluetoothAvailable) {
                                        InCallActionTile(
                                            icon = Icons.Rounded.BluetoothAudio,
                                            label = strings.bluetooth,
                                            isActive = callState.isBluetoothActive,
                                            onClick = onToggleBluetooth,
                                            testTag = "incall_bluetooth_button",
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Action Area (Swipe or Single Tap for Ringing; End button for Active/Dialing)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp),
            ) {
                if (callState.status == ActiveCallStatus.RINGING) {
                    TextButton(
                        onClick = { showQuickSmsSheet = true },
                        modifier = Modifier.padding(bottom = 18.dp),
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.Message,
                            contentDescription = null,
                            tint = Color(0xFFA8C7FA),
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(strings.replyWithSms, color = Color(0xFFA8C7FA))
                    }

                    if (incomingCallGesture == IncomingCallGesture.SWIPE) {
                        SwipeCallGestureBar(
                            strings = strings,
                            onAnswer = onAnswer,
                            onDecline = { onDecline(null) },
                        )
                    } else {
                        SingleTapCallButtons(
                            strings = strings,
                            onAnswer = onAnswer,
                            onDecline = { onDecline(null) },
                        )
                    }
                } else {
                    Button(
                        onClick = onEndCall,
                        colors = ButtonDefaults.buttonColors(containerColor = MissedRed),
                        shape = CircleShape,
                        modifier = Modifier
                            .size(width = 96.dp, height = 64.dp)
                            .testTag("incall_end_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CallEnd,
                            contentDescription = strings.endCall,
                            tint = Color.White,
                            modifier = Modifier.size(30.dp),
                        )
                    }
                }
            }
        }
    }

    if (showQuickSmsSheet) {
        ModalBottomSheet(onDismissRequest = { showQuickSmsSheet = false }) {
            Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                Text(
                    text = strings.replyWithSms,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(bottom = 12.dp),
                )
                quickResponses.forEach { msg ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable {
                                showQuickSmsSheet = false
                                onDecline(msg)
                            },
                    ) {
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(16.dp),
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun SwipeCallGestureBar(
    strings: AppStrings,
    onAnswer: () -> Unit,
    onDecline: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val offsetX = remember { Animatable(0f) }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Text(
            text = strings.swipeToAnswerHint,
            style = MaterialTheme.typography.labelMedium,
            color = Color.White.copy(alpha = 0.85f),
            modifier = Modifier.padding(bottom = 12.dp),
        )
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(78.dp)
                .clip(RoundedCornerShape(44.dp))
                .background(Color.White.copy(alpha = 0.14f))
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center,
        ) {
            val maxTravelPx = with(LocalDensity.current) {
                ((maxWidth - 88.dp) / 2f).toPx().coerceAtLeast(60f)
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Surface(
                    onClick = onDecline,
                    shape = CircleShape,
                    color = MissedRed.copy(alpha = 0.85f),
                    modifier = Modifier
                        .size(52.dp)
                        .testTag("incall_swipe_decline_target"),
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Rounded.CallEnd,
                            contentDescription = strings.decline,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp),
                        )
                    }
                }

                Surface(
                    onClick = onAnswer,
                    shape = CircleShape,
                    color = CallGreenBright.copy(alpha = 0.85f),
                    modifier = Modifier
                        .size(52.dp)
                        .testTag("incall_swipe_answer_target"),
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Rounded.Call,
                            contentDescription = strings.answer,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp),
                        )
                    }
                }
            }

            val dragState = rememberDraggableState { delta ->
                scope.launch {
                    val target = (offsetX.value + delta).coerceIn(-maxTravelPx, maxTravelPx)
                    offsetX.snapTo(target)
                }
            }

            Surface(
                shape = CircleShape,
                color = Color.White,
                shadowElevation = 6.dp,
                modifier = Modifier
                    .offset { IntOffset(offsetX.value.roundToInt(), 0) }
                    .size(62.dp)
                    .draggable(
                        state = dragState,
                        orientation = Orientation.Horizontal,
                        onDragStopped = {
                            val current = offsetX.value
                            if (current >= maxTravelPx * 0.65f) {
                                onAnswer()
                            } else if (current <= -maxTravelPx * 0.65f) {
                                onDecline()
                            } else {
                                scope.launch {
                                    offsetX.animateTo(0f, spring())
                                }
                            }
                        },
                    )
                    .testTag("incall_swipe_handle"),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.Call,
                        contentDescription = strings.swipeToAnswerHint,
                        tint = when {
                            offsetX.value > 25f -> CallGreenBright
                            offsetX.value < -25f -> MissedRed
                            else -> Color(0xFF0A192F)
                        },
                        modifier = Modifier.size(28.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun SingleTapCallButtons(
    strings: AppStrings,
    onAnswer: () -> Unit,
    onDecline: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(
                onClick = onDecline,
                shape = CircleShape,
                color = MissedRed,
                modifier = Modifier
                    .size(72.dp)
                    .testTag("incall_decline_button"),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.CallEnd,
                        contentDescription = strings.decline,
                        tint = Color.White,
                        modifier = Modifier.size(32.dp),
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(strings.decline, color = Color.White, style = MaterialTheme.typography.labelLarge)
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(
                onClick = onAnswer,
                shape = CircleShape,
                color = CallGreenBright,
                modifier = Modifier
                    .size(72.dp)
                    .testTag("incall_answer_button"),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Rounded.Call,
                        contentDescription = strings.answer,
                        tint = Color.White,
                        modifier = Modifier.size(32.dp),
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(strings.answer, color = Color.White, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun InCallActionTile(
    icon: ImageVector,
    label: String,
    isActive: Boolean,
    activeTint: Color = Color(0xFF0A192F),
    onClick: () -> Unit,
    testTag: String,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(86.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp)
            .testTag(testTag),
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(if (isActive) Color.White else Color.White.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isActive) activeTint else Color.White,
                modifier = Modifier.size(26.dp),
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = label,
            color = Color.White,
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
