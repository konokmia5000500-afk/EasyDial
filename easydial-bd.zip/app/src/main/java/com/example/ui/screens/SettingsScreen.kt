package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Message
import androidx.compose.material.icons.automirrored.rounded.ViewList
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.FiberManualRecord
import androidx.compose.material.icons.rounded.FlipCameraAndroid
import androidx.compose.material.icons.rounded.PhoneEnabled
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.SimCard
import androidx.compose.material.icons.rounded.Swipe
import androidx.compose.material.icons.rounded.Tag
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.CallerIdAnnouncementMode
import com.example.model.DialerSettings
import com.example.model.IncomingCallGesture
import com.example.model.PermissionStatus
import com.example.model.RecordingAnnouncementMode
import com.example.model.SimAccountInfo
import com.example.model.SimPreference
import com.example.ui.components.consumeBackgroundTouches
import com.example.ui.theme.CallGreenBright
import com.example.util.AppStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: DialerSettings,
    permissions: PermissionStatus,
    simAccounts: List<SimAccountInfo>,
    recordingsCount: Int,
    strings: AppStrings,
    onBack: () -> Unit,
    onSetDefaultDialer: () -> Unit,
    onOpenCallerIdSpam: () -> Unit,
    onOpenBlockedNumbers: () -> Unit,
    onOpenCallingAccounts: () -> Unit,
    onOpenCallRecordingSettings: () -> Unit,
    onOpenDisplayOptions: () -> Unit,
    onOpenIncomingGesture: () -> Unit,
    onOpenQuickResponses: () -> Unit,
    onOpenSoundsVibration: () -> Unit,
    onOpenCallingCard: () -> Unit,
    onOpenCallerIdAnnouncement: () -> Unit,
    onOpenFlipToSilence: () -> Unit,
    onOpenUssdDirectory: () -> Unit,
) {
    BackHandler(onBack = onBack)

    Surface(
        color = MaterialTheme.colorScheme.background,
        modifier = Modifier
            .fillMaxSize()
            .consumeBackgroundTouches(),
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(strings.settings) },
                    navigationIcon = {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("settings_back_button"),
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                            )
                        }
                    },
                )
            },
        ) { innerPadding ->
            LazyColumn(
                contentPadding = PaddingValues(
                    start = 16.dp,
                    end = 16.dp,
                    top = innerPadding.calculateTopPadding() + 4.dp,
                    bottom = innerPadding.calculateBottomPadding() + 24.dp,
                ),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                if (!permissions.isDefaultDialer) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 4.dp),
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.PhoneEnabled,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                                Spacer(Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = strings.setDefaultDialerTitle,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold,
                                    )
                                    Text(
                                        text = strings.setDefaultDialerDesc,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                Spacer(Modifier.width(8.dp))
                                Button(onClick = onSetDefaultDialer) {
                                    Text(strings.setDefaultButton)
                                }
                            }
                        }
                    }
                } else {
                    item {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.55f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 4.dp),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = null,
                                    tint = CallGreenBright,
                                )
                                Spacer(Modifier.width(12.dp))
                                Text(
                                    text = strings.defaultDialerActive,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                )
                            }
                        }
                    }
                }

                // Section 1: Call Assist (Matches Screenshot 2 & 4)
                item {
                    SettingsSectionHeader(strings.settingsCallAssist)
                }
                item {
                    GoogleSettingsRow(
                        icon = Icons.Rounded.Shield,
                        title = strings.settingsCallerIdSpam,
                        subtitle = if (settings.callerIdAndSpamEnabled) strings.settingsCallerIdSpamDesc else null,
                        onClick = onOpenCallerIdSpam,
                        testTag = "setting_caller_id_spam_row",
                    )
                }

                // Section 2: General (Matches Screenshot 2 & 4)
                item {
                    SettingsSectionHeader(strings.settingsGeneral)
                }
                item {
                    val blockedSummary = if (settings.blockedNumbers.isEmpty()) {
                        strings.blockedCountZero
                    } else {
                        "${settings.blockedNumbers.size}"
                    }
                    GoogleSettingsRow(
                        icon = Icons.Rounded.Block,
                        title = strings.settingsBlockedNumbers,
                        subtitle = blockedSummary,
                        onClick = onOpenBlockedNumbers,
                        testTag = "setting_blocked_numbers_row",
                    )
                }
                item {
                    val simSummary = when (settings.simPreference) {
                        SimPreference.ASK_EVERY_TIME -> strings.simAskEveryTime
                        SimPreference.SIM_1 -> simAccounts.getOrNull(0)?.carrierName ?: strings.simAlways1
                        SimPreference.SIM_2 -> simAccounts.getOrNull(1)?.carrierName ?: strings.simAlways2
                    }
                    GoogleSettingsRow(
                        icon = Icons.Rounded.SimCard,
                        title = strings.settingsCallingAccounts,
                        subtitle = simSummary,
                        onClick = onOpenCallingAccounts,
                        testTag = "setting_calling_accounts_row",
                    )
                }
                item {
                    val recSummary = if (!settings.callRecordingEnabled) {
                        null
                    } else if (settings.recordingAnnouncementMode == RecordingAnnouncementMode.ANNOUNCE_BOTH_SIDES) {
                        "${strings.announceBothSidesTitle} • $recordingsCount"
                    } else {
                        "${strings.silentRecordTitle} • $recordingsCount"
                    }
                    GoogleSettingsRow(
                        icon = Icons.Rounded.FiberManualRecord,
                        title = strings.callRecordingTitle,
                        subtitle = recSummary,
                        onClick = onOpenCallRecordingSettings,
                        testTag = "setting_call_recording_row",
                    )
                }
                item {
                    GoogleSettingsRow(
                        icon = Icons.AutoMirrored.Rounded.ViewList,
                        title = strings.settingsDisplayOptions,
                        subtitle = settings.language.displayName,
                        onClick = onOpenDisplayOptions,
                        testTag = "setting_display_options_row",
                    )
                }
                item {
                    val gestureSummary = when (settings.incomingCallGesture) {
                        IncomingCallGesture.SWIPE -> strings.gestureSwipeTitle
                        IncomingCallGesture.SINGLE_TAP -> strings.gestureSingleTapTitle
                    }
                    GoogleSettingsRow(
                        icon = Icons.Rounded.Swipe,
                        title = strings.settingsIncomingCallGesture,
                        subtitle = gestureSummary,
                        onClick = onOpenIncomingGesture,
                        testTag = "setting_incoming_gesture_row",
                    )
                }
                item {
                    GoogleSettingsRow(
                        icon = Icons.AutoMirrored.Rounded.Message,
                        title = strings.settingsQuickResponses,
                        subtitle = null,
                        onClick = onOpenQuickResponses,
                        testTag = "setting_quick_responses_row",
                    )
                }
                item {
                    GoogleSettingsRow(
                        icon = Icons.AutoMirrored.Rounded.VolumeUp,
                        title = strings.settingsSoundsVibration,
                        subtitle = null,
                        onClick = onOpenSoundsVibration,
                        testTag = "setting_sounds_vibration_row",
                    )
                }
                item {
                    GoogleSettingsRow(
                        icon = Icons.Rounded.Badge,
                        title = strings.settingsCallingCard,
                        subtitle = null,
                        onClick = onOpenCallingCard,
                        testTag = "setting_calling_card_row",
                    )
                }

                // Section 3: Advanced (Matches Screenshot 4)
                item {
                    SettingsSectionHeader(strings.settingsAdvanced)
                }
                item {
                    val announceLabel = when (settings.callerIdAnnouncement) {
                        CallerIdAnnouncementMode.ALWAYS -> strings.announceCallerAlways
                        CallerIdAnnouncementMode.NEVER -> strings.announceCallerNever
                    }
                    GoogleSettingsRow(
                        icon = Icons.Rounded.Campaign,
                        title = strings.settingsCallerIdAnnouncement,
                        subtitle = announceLabel,
                        onClick = onOpenCallerIdAnnouncement,
                        testTag = "setting_caller_id_announcement_row",
                    )
                }
                item {
                    GoogleSettingsRow(
                        icon = Icons.Rounded.FlipCameraAndroid,
                        title = strings.settingsFlipToSilence,
                        subtitle = if (settings.flipToSilence) strings.flipToSilenceDesc else null,
                        onClick = onOpenFlipToSilence,
                        testTag = "setting_flip_to_silence_row",
                    )
                }
                item {
                    GoogleSettingsRow(
                        icon = Icons.Rounded.Tag,
                        title = strings.ussdCodes,
                        subtitle = strings.settingsBdUssdSubtitle,
                        onClick = onOpenUssdDirectory,
                        testTag = "setting_ussd_row",
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 10.dp, top = 10.dp, bottom = 2.dp),
    )
}

@Composable
private fun GoogleSettingsRow(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    testTag: String,
    onClick: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.width(18.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                )
                if (!subtitle.isNullOrBlank()) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
