package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.example.model.ThemeMode

private val DarkColorScheme = darkColorScheme(
    primary = DialerSkyLight,
    onPrimary = Color(0xFF062E6F),
    primaryContainer = DialerSkyDarkContainer,
    onPrimaryContainer = DialerBlueContainer,
    secondary = Color(0xFFBEC6DC),
    onSecondary = Color(0xFF283041),
    secondaryContainer = Color(0xFF334459),
    onSecondaryContainer = Color(0xFFDCE7F9),
    tertiary = Color(0xFF7FD99A),
    onTertiary = Color(0xFF003919),
    background = DialerSurfaceDark,
    onBackground = DialerOnSurfaceDark,
    surface = DialerSurfaceDark,
    onSurface = DialerOnSurfaceDark,
    surfaceVariant = DialerSurfaceVariantDark,
    onSurfaceVariant = DialerOnSurfaceVariantDark,
    surfaceContainerLowest = Color(0xFF0A0E12),
    surfaceContainerLow = Color(0xFF141A21),
    surfaceContainer = DialerCardDark,
    surfaceContainerHigh = Color(0xFF1E2630),
    surfaceContainerHighest = Color(0xFF28323E),
    error = MissedRedDark,
    outlineVariant = Color(0xFF2E3844),
)

private val LightColorScheme = lightColorScheme(
    primary = DialerBlue,
    onPrimary = Color.White,
    primaryContainer = DialerBlueContainer,
    onPrimaryContainer = DialerOnBlueContainer,
    secondary = Color(0xFF535E71),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD7E3F8),
    onSecondaryContainer = Color(0xFF101C2B),
    tertiary = CallGreen,
    onTertiary = Color.White,
    background = DialerSurfaceLight,
    onBackground = DialerOnSurfaceLight,
    surface = DialerSurfaceLight,
    onSurface = DialerOnSurfaceLight,
    surfaceVariant = DialerSurfaceVariantLight,
    onSurfaceVariant = DialerOnSurfaceVariantLight,
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF2F6FC),
    surfaceContainer = Color(0xFFEDF2FA),
    surfaceContainerHigh = Color(0xFFE6ECF7),
    surfaceContainerHighest = Color(0xFFDFE6F2),
    error = MissedRed,
    outlineVariant = Color(0xFFD6DEE8),
)

@Composable
fun AlaapPhoneTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit,
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = DialerTypography,
        content = content,
    )
}
