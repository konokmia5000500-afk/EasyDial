package com.example.ui.screens

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Tag
import androidx.compose.material.icons.rounded.Voicemail
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.SimAccountInfo
import com.example.ui.T9Suggestion
import com.example.ui.components.CarrierBadgeChip
import com.example.ui.components.ContactAvatar
import com.example.ui.theme.CallGreenBright
import com.example.util.AppStrings
import com.example.util.BangladeshTelecomHelper

private data class KeypadKey(
    val digit: String,
    val letters: String,
    val tone: Int,
)

private val keypadRows = listOf(
    listOf(
        KeypadKey("1", "", ToneGenerator.TONE_DTMF_1),
        KeypadKey("2", "ABC", ToneGenerator.TONE_DTMF_2),
        KeypadKey("3", "DEF", ToneGenerator.TONE_DTMF_3),
    ),
    listOf(
        KeypadKey("4", "GHI", ToneGenerator.TONE_DTMF_4),
        KeypadKey("5", "JKL", ToneGenerator.TONE_DTMF_5),
        KeypadKey("6", "MNO", ToneGenerator.TONE_DTMF_6),
    ),
    listOf(
        KeypadKey("7", "PQRS", ToneGenerator.TONE_DTMF_7),
        KeypadKey("8", "TUV", ToneGenerator.TONE_DTMF_8),
        KeypadKey("9", "WXYZ", ToneGenerator.TONE_DTMF_9),
    ),
    listOf(
        KeypadKey("*", "", ToneGenerator.TONE_DTMF_S),
        KeypadKey("0", "+", ToneGenerator.TONE_DTMF_0),
        KeypadKey("#", "", ToneGenerator.TONE_DTMF_P),
    ),
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun KeypadScreen(
    digits: String,
    suggestions: List<T9Suggestion>,
    simAccounts: List<SimAccountInfo>,
    selectedSimIndex: Int,
    dialpadTonesEnabled: Boolean,
    dialpadVibrateEnabled: Boolean,
    language: AppLanguage,
    strings: AppStrings,
    onSelectSimIndex: (Int) -> Unit,
    onDigitClick: (String) -> Unit,
    onBackspace: () -> Unit,
    onClearAll: () -> Unit,
    onCall: (String, Boolean) -> Unit,
    onAddContact: (String) -> Unit,
    onOpenUssdCodes: () -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    val toneGenerator = remember {
        runCatching { ToneGenerator(AudioManager.STREAM_DTMF, 75) }.getOrNull()
    }
    DisposableEffect(Unit) {
        onDispose {
            runCatching { toneGenerator?.release() }
        }
    }

    val detectedCarrier = remember(digits) { BangladeshTelecomHelper.detectCarrier(digits) }
    val isUssd = remember(digits) { BangladeshTelecomHelper.isUssdCode(digits) }
    var simMenuExpanded by remember { mutableStateOf(false) }
    var keypadMenuExpanded by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Top Matching Contacts & History List (Screenshot 3 style!)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
        ) {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                item(key = "all_contacts_header") {
                    Text(
                        text = strings.allContactsHeader,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(start = 6.dp, bottom = 2.dp),
                    )
                }

                if (digits.isNotEmpty() && !isUssd && suggestions.isEmpty()) {
                    item(key = "create_from_digits") {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLowest,
                            tonalElevation = 1.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .clickable { onAddContact(digits) }
                                .testTag("keypad_add_contact_row"),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.PersonAdd,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                                Spacer(Modifier.width(12.dp))
                                Text(
                                    text = "${strings.createNewContact}: $digits",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }
                    }
                }

                items(suggestions, key = { it.id }) { suggestion ->
                    SuggestionContactCard(
                        suggestion = suggestion,
                        strings = strings,
                        primaryHighlightColor = MaterialTheme.colorScheme.primary,
                        onCall = { onCall(suggestion.number, true) },
                    )
                }
            }
        }

        // Bottom Rounded Keypad Container (Screenshot 3 style!)
        Surface(
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
            color = MaterialTheme.colorScheme.surfaceContainerLow,
            tonalElevation = 3.dp,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                // SIM Selector Pill or Carrier/USSD Pill
                if (simAccounts.isNotEmpty()) {
                    val activeSim = simAccounts.getOrNull(selectedSimIndex) ?: simAccounts.first()
                    Box {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerHigh,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    if (simAccounts.size > 1) simMenuExpanded = true
                                }
                                .testTag("keypad_sim_pill"),
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = MaterialTheme.colorScheme.primary,
                                ) {
                                    Text(
                                        text = "${activeSim.slotIndex + 1}",
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp),
                                    )
                                }
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = activeSim.carrierName,
                                    style = MaterialTheme.typography.labelLarge,
                                )
                                if (simAccounts.size > 1) {
                                    Spacer(Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Rounded.ArrowDropDown,
                                        contentDescription = strings.chooseSimTitle,
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                            }
                        }

                        DropdownMenu(
                            expanded = simMenuExpanded,
                            onDismissRequest = { simMenuExpanded = false },
                        ) {
                            simAccounts.forEachIndexed { idx, sim ->
                                DropdownMenuItem(
                                    text = { Text("${sim.displayName} • ${sim.carrierName}") },
                                    onClick = {
                                        onSelectSimIndex(idx)
                                        simMenuExpanded = false
                                    },
                                )
                            }
                        }
                    }
                } else if (isUssd) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(50),
                    ) {
                        Text(
                            text = strings.ussdCodeDetected,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        )
                    }
                } else if (detectedCarrier != null) {
                    CarrierBadgeChip(carrier = detectedCarrier, language = language)
                }

                // Number Display Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box {
                        IconButton(onClick = { keypadMenuExpanded = true }) {
                            Icon(
                                imageVector = Icons.Rounded.MoreVert,
                                contentDescription = "Options",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        DropdownMenu(
                            expanded = keypadMenuExpanded,
                            onDismissRequest = { keypadMenuExpanded = false },
                        ) {
                            if (digits.isNotEmpty() && !isUssd) {
                                DropdownMenuItem(
                                    text = { Text(strings.createNewContact) },
                                    leadingIcon = { Icon(Icons.Rounded.PersonAdd, contentDescription = null) },
                                    onClick = {
                                        keypadMenuExpanded = false
                                        onAddContact(digits)
                                    },
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("Add 2-sec pause (,)") },
                                onClick = {
                                    keypadMenuExpanded = false
                                    onDigitClick(",")
                                },
                            )
                            DropdownMenuItem(
                                text = { Text("Add wait (;)") },
                                onClick = {
                                    keypadMenuExpanded = false
                                    onDigitClick(";")
                                },
                            )
                            DropdownMenuItem(
                                text = { Text(strings.ussdCodes) },
                                leadingIcon = { Icon(Icons.Rounded.Tag, contentDescription = null) },
                                onClick = {
                                    keypadMenuExpanded = false
                                    onOpenUssdCodes()
                                },
                            )
                        }
                    }

                    Text(
                        text = if (digits.isEmpty()) "" else BangladeshTelecomHelper.formatPhoneNumber(digits),
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontSize = when {
                                digits.length > 14 -> 22.sp
                                digits.length > 11 -> 27.sp
                                else -> 32.sp
                            },
                        ),
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialpad_display_text"),
                    )

                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .combinedClickable(
                                enabled = digits.isNotEmpty(),
                                onClick = onBackspace,
                                onLongClick = onClearAll,
                            )
                            .testTag("dialpad_backspace_button"),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (digits.isNotEmpty()) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.Backspace,
                                contentDescription = strings.delete,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }

                // 3x4 Pill Keypad Grid
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 22.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    keypadRows.forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            row.forEach { key ->
                                Surface(
                                    shape = RoundedCornerShape(30.dp),
                                    color = MaterialTheme.colorScheme.surfaceContainerLowest,
                                    tonalElevation = 1.dp,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(58.dp)
                                        .clip(RoundedCornerShape(30.dp))
                                        .combinedClickable(
                                            onClick = {
                                                if (dialpadVibrateEnabled) {
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                }
                                                if (dialpadTonesEnabled) {
                                                    runCatching { toneGenerator?.startTone(key.tone, 80) }
                                                }
                                                onDigitClick(key.digit)
                                            },
                                            onLongClick = {
                                                if (key.digit == "0") {
                                                    if (dialpadVibrateEnabled) {
                                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                    }
                                                    onDigitClick("+")
                                                }
                                            },
                                        )
                                        .testTag("dialpad_key_${key.digit}"),
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center,
                                    ) {
                                        Text(
                                            text = key.digit,
                                            fontSize = 24.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onSurface,
                                        )
                                        if (key.digit == "1") {
                                            Icon(
                                                imageVector = Icons.Rounded.Voicemail,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(13.dp),
                                            )
                                        } else if (key.letters.isNotEmpty()) {
                                            Text(
                                                text = key.letters,
                                                fontSize = 10.sp,
                                                letterSpacing = 1.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                // Green Pill Call Button
                Button(
                    onClick = {
                        if (digits.isNotBlank()) {
                            onCall(digits, true)
                        }
                    },
                    enabled = digits.isNotBlank(),
                    shape = RoundedCornerShape(32.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CallGreenBright,
                        contentColor = Color.White,
                    ),
                    modifier = Modifier
                        .height(54.dp)
                        .width(136.dp)
                        .testTag("dialpad_call_button"),
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Call,
                        contentDescription = strings.callAction,
                        modifier = Modifier.size(22.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = if (isUssd) strings.dialUssdCode else strings.callAction,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }
    }
}

@Composable
private fun SuggestionContactCard(
    suggestion: T9Suggestion,
    strings: AppStrings,
    primaryHighlightColor: Color,
    onCall: () -> Unit,
) {
    val highlightedNumber = remember(suggestion.formattedNumber, suggestion.matchedQuery, primaryHighlightColor) {
        val text = suggestion.formattedNumber
        val query = suggestion.matchedQuery
        if (query.isBlank()) {
            AnnotatedString(text)
        } else {
            val startIndex = text.indexOf(query, ignoreCase = true)
            if (startIndex >= 0) {
                buildAnnotatedString {
                    append(text.substring(0, startIndex))
                    withStyle(SpanStyle(color = primaryHighlightColor, fontWeight = FontWeight.Bold)) {
                        append(text.substring(startIndex, startIndex + query.length))
                    }
                    append(text.substring(startIndex + query.length))
                }
            } else {
                // Match contiguous digits across formatting hyphens/spaces
                val digitPositions = mutableListOf<Int>()
                val pureDigits = StringBuilder()
                text.forEachIndexed { idx, ch ->
                    if (ch.isDigit()) {
                        digitPositions.add(idx)
                        pureDigits.append(ch)
                    }
                }
                val digitMatchStart = pureDigits.toString().indexOf(query)
                if (digitMatchStart >= 0 && digitMatchStart + query.length <= digitPositions.size) {
                    val matchIndices = digitPositions
                        .subList(digitMatchStart, digitMatchStart + query.length)
                        .toSet()
                    buildAnnotatedString {
                        text.forEachIndexed { idx, ch ->
                            if (idx in matchIndices) {
                                withStyle(SpanStyle(color = primaryHighlightColor, fontWeight = FontWeight.Bold)) {
                                    append(ch)
                                }
                            } else {
                                append(ch)
                            }
                        }
                    }
                } else {
                    AnnotatedString(text)
                }
            }
        }
    }

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        tonalElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onCall)
            .testTag("keypad_suggestion_${suggestion.id}"),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ContactAvatar(
                name = suggestion.displayName,
                number = suggestion.number,
                photoUri = suggestion.photoUri,
                callingCardPath = suggestion.callingCardPath,
                size = 44.dp,
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = suggestion.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = highlightedNumber,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            IconButton(onClick = onCall) {
                Icon(
                    imageVector = Icons.Rounded.Call,
                    contentDescription = strings.callAction,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
